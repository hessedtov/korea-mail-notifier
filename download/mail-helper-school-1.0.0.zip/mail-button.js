// 공직자통합메일 화면에 '빠른 검색' 탭을 여는 버튼을 붙입니다. (탭은 받은메일함·메일보기 탭 옆에 생김)
//  1) 위쪽 파란 메뉴 줄: '메일홈 뉴스' 오른쪽
//  2) 메일 검색창 옆('상세' 오른쪽): '빠른 검색' — 검색창에 쓴 낱말을 그대로 넘겨 줌
// 화면만 바꾸며, 서버에는 아무 요청도 보내지 않습니다.
(function () {
  "use strict";
  const MARK = "kmn-plus-btn";

  // 확장프로그램을 업데이트·다시 켜면 이미 열려 있던 메일 화면의 버튼은 연결이 끊김 → 새로 고침 안내
  // 메일 화면 안에 '🔍 빠른 검색' 탭을 열어 그 안에서 찾음 (받은메일함 탭 옆)
  function openSearch(q) {
    try {
      if (!chrome.runtime || !chrome.runtime.id) throw new Error("끊김");
      chrome.runtime.sendMessage({ type: "openQuickTab", q: q || "" }).catch(() => {});
    } catch {
      alert("공직자통합메일도우미(학교)가 업데이트되었습니다.\n메일 화면을 새로 고침(F5)한 뒤 다시 눌러 주세요.");
    }
  }

  const USED_KEY = "quickSearchUsed";
  function getUsed(cb) {
    try { chrome.storage.local.get(USED_KEY, (r) => cb(!!(r && r[USED_KEY]))); } catch { cb(true); }
  }
  let usedNow = false;
  function markUsed() {
    if (usedNow) return;
    usedNow = true;
    const b = document.querySelector("td." + MARK + "-tool button");
    if (b) b.classList.remove("pulse");
    document.querySelectorAll("td." + MARK + "-box .tip").forEach((x) => x.remove());
    try { chrome.storage.local.set({ [USED_KEY]: true }); } catch {}
  }

  function addStyle() {
    if (document.getElementById(MARK + "-css")) return;
    const st = document.createElement("style");
    st.id = MARK + "-css";
    st.textContent = `
      td.${MARK}-top { width: 140px; height: 64px; padding: 0; vertical-align: middle; }
      td.${MARK}-top a { display: flex; flex-direction: row; align-items: center; justify-content: center; gap: 8px;
        height: 64px; color: #fff !important; text-decoration: none; font: 13px "Malgun Gothic", sans-serif; }
      td.${MARK}-top a:hover { background: rgba(255,255,255,.13); }
      td.${MARK}-top .ic { width: 30px; height: 26px; border: 2px solid #fff; border-radius: 4px; display: grid; place-items: center;
        font-size: 17px; font-weight: 700; line-height: 1; }
      td.${MARK}-top .lb { color: #fff; white-space: nowrap; }
      td.${MARK}-tool { padding: 0 0 0 8px; vertical-align: middle; white-space: nowrap; }
      td.${MARK}-tool button { height: 30px; padding: 0 16px 0 12px; border: 1px solid #1f6fd6; background: #2b7de9; color: #fff;
        font: bold 14px "Malgun Gothic", sans-serif; border-radius: 3px; cursor: pointer; white-space: nowrap;
        box-shadow: 0 1px 3px rgba(0,0,0,.25); vertical-align: middle; }
      td.${MARK}-tool button .ic { display: inline-block; margin-right: 5px; font-size: 16px; }
      /* 늘 짙은 파랑 ↔ 연한 파랑으로 은은하게 숨 쉬듯 바뀜. 마우스를 올리면 멈추고 짙은 파랑 */
      td.${MARK}-tool button { animation: ${MARK}-breathe 2.6s ease-in-out infinite; }
      td.${MARK}-tool button:hover { animation: none; background: #1554b8; border-color: #1554b8; }
      @keyframes ${MARK}-breathe {
        0%, 100% { background: #1a5fc8; border-color: #1554b8; }
        50%      { background: #5aa2f2; border-color: #4a92e6; }
      }
      /* 아직 한 번도 안 눌렀을 때만: 바깥으로 연한 파란 빛이 번짐 */
      td.${MARK}-tool button.pulse { animation: ${MARK}-breathe 2.6s ease-in-out infinite, ${MARK}-ring 2.6s ease-out infinite; }
      @keyframes ${MARK}-ring {
        0%   { box-shadow: 0 0 0 0 rgba(90,162,242,.7); }
        70%  { box-shadow: 0 0 0 8px rgba(90,162,242,0); }
        100% { box-shadow: 0 0 0 0 rgba(90,162,242,0); }
      }
      /* 처음 한 번만: 빠른 검색 칸 바로 아래 말풍선 (줄 너비를 늘리지 않게 칸 위에 떠 있음) */
      td.${MARK}-box .wrap { position: relative; display: inline-block; vertical-align: middle; }
      td.${MARK}-box .tip { position: absolute; left: 0; top: calc(100% + 7px); z-index: 9000; padding: 4px 9px; background: #fff7d6;
        border: 1px solid #f0c040; border-radius: 3px; color: #7a5a00; font: 12px "Malgun Gothic", sans-serif; white-space: nowrap;
        box-shadow: 0 2px 6px rgba(0,0,0,.15); cursor: pointer; }
      td.${MARK}-box .tip::before { content: ""; position: absolute; left: 18px; top: -6px;
        border: 6px solid transparent; border-bottom-color: #f0c040; border-top: 0; }
      /* 빠른 검색 글자 칸: 파란 테두리·연한 파란 바탕으로 메일 검색창과 구분 */
      td.${MARK}-box { padding: 0 0 0 10px; vertical-align: middle; white-space: nowrap; }
      td.${MARK}-box label { display: inline-flex; align-items: center; gap: 6px; width: 340px; height: 30px; box-sizing: border-box;
        padding: 0 10px; border: 2px solid #2b7de9; border-radius: 3px; background: #f0f6ff; cursor: text; vertical-align: middle; }
      td.${MARK}-box label:focus-within { background: #fff; box-shadow: 0 0 0 3px rgba(43,125,233,.25); }
      td.${MARK}-box .ic { font-size: 14px; line-height: 1; }
      td.${MARK}-box input { flex: 1; min-width: 0; border: 0; outline: none; background: transparent; height: 24px; padding: 0;
        font: 13px "Malgun Gothic", sans-serif; color: #222; }
      td.${MARK}-box input::placeholder { color: #5b84b8; }
      /* 윈도우 '애니메이션 효과'를 끈 PC: 움직이는 빛 번짐만 빼고, 은은한 색 변화는 남김 */
      @media (prefers-reduced-motion: reduce) { td.${MARK}-tool button.pulse { animation: ${MARK}-breathe 2.6s ease-in-out infinite; } }
    `;
    document.head.appendChild(st);
  }

  // 1) 위쪽 메뉴
  function addTopButton() {
    if (document.querySelector("td." + MARK + "-top")) return;
    const cells = document.querySelectorAll("table.top-tbl td.btn-top");
    if (!cells.length) return;
    const last = cells[cells.length - 1];
    const td = document.createElement("td");
    td.className = MARK + "-top";
    td.innerHTML = '<a href="javascript:;" title="모아 둔 메일 목록에서 빠르게 찾기 (공직자통합메일도우미(학교), 비공식)">' +
      '<span class="ic">⌕</span><span class="lb">빠른 검색</span></a>';
    td.querySelector("a").addEventListener("click", (e) => { e.preventDefault(); openSearch(""); });
    last.after(td);
  }

  // 2) 검색창 옆
  function addToolButton() {
    if (document.querySelector("td." + MARK + "-tool")) return;
    const btn = document.getElementById("r3-mail-search-btn");
    const cell = btn && btn.closest("td");
    if (!cell) return;
    const td = document.createElement("td");
    td.className = MARK + "-tool";
    td.innerHTML = '<button type="button" title="검색창에 쓴 낱말로 ‘빠른 검색’ 탭에서 찾기 (띄어쓰기·초성·비슷한 말도 찾음)">' +
      '<span class="ic">🔍</span>빠른 검색</button>';
    const button = td.querySelector("button");
    button.addEventListener("click", (e) => {
      e.preventDefault(); e.stopPropagation();
      // 오른쪽 빠른 검색 칸에 쓴 낱말이 있으면 그것을, 없으면 메일 검색창 낱말을 넘김
      const mine = document.querySelector("td." + MARK + "-box input");
      const inp = document.getElementById("r3-mail-search-textfield");
      const q = (mine && mine.value.trim()) || (inp ? inp.value.trim() : "");
      if (mine && !mine.value.trim() && q) mine.value = q;
      openSearch(q);
      markUsed();
    });
    cell.after(td);
    // 색 변화는 늘 있음. 한 번도 써 보지 않았으면 빛 번짐을 더함 (한 번 쓰면 사라짐)
    getUsed((used) => { if (!used && !usedNow) button.classList.add("pulse"); });
  }

  // 3) '빠른 검색' 버튼 오른쪽의 빈자리에 빠른 검색 글자 칸
  //    치는 대로 '🔍 빠른 검색' 탭에서 바로 찾음 (이 PC에 모아 둔 목록만 찾음, 서버 요청 없음)
  //    탭 안 화면과는 postMessage로 낱말만 주고받음 (탭 안 화면은 확장프로그램 주소, 메일 화면에서 온 것만 받음)
  const EXT_ORIGIN = (() => { try { return "chrome-extension://" + chrome.runtime.id; } catch { return ""; } })();
  const quickFrame = () => document.querySelector('iframe[src*="search.html?embed=1"]');
  // 탭 안 화면이 다 떠서 말을 받을 수 있는지 (막 연 탭은 화면이 뜨기 전이라 보낸 낱말이 사라짐)
  let readyWin = null;
  let pendingEnter = false;
  const post = (f, m) => { try { f.contentWindow.postMessage(m, EXT_ORIGIN); } catch {} };
  function sendQ(q, enter) {
    const f = quickFrame();
    // 빠른 검색 탭이 열려 있고 보이면 그 안으로 바로, 아니면 탭을 열거나 앞으로 (글자 칸에서 커서를 빼앗지 않게)
    if (f && f.offsetParent && f.contentWindow) {
      if (f.contentWindow !== readyWin) { if (enter) pendingEnter = true; return; } // 뜨고 나면 지금 낱말을 한 번에 보냄
      post(f, { kmhQuick: "setQ", q });
      if (enter) post(f, { kmhQuick: "enter" });
      return;
    }
    if (f && f.contentWindow && f.contentWindow === readyWin) {
      // 탭은 있는데 다른 탭(받은메일함 등)을 보고 있음: 낱말은 바로 넘기고, 아래에서 탭만 앞으로
      post(f, { kmhQuick: "setQ", q });
      if (enter) post(f, { kmhQuick: "enter" });
    } else if (enter) pendingEnter = true;
    try {
      if (!chrome.runtime || !chrome.runtime.id) throw new Error("끊김");
      chrome.runtime.sendMessage({ type: "openQuickTab", q, nf: true }).catch(() => {});
    } catch {
      alert("공직자통합메일도우미(학교)가 업데이트되었습니다.\n메일 화면을 새로 고침(F5)한 뒤 다시 눌러 주세요.");
    }
  }
  function addQuickBox() {
    if (document.querySelector("td." + MARK + "-box")) return;
    const tool = document.querySelector("td." + MARK + "-tool");
    if (!tool) return;
    const td = document.createElement("td");
    td.className = MARK + "-box";
    td.innerHTML = '<span class="wrap"><label title="이 PC에 모아 둔 메일 목록에서 바로 찾습니다 (띄어쓰기·초성·비슷한 말도). 공직자통합메일도우미(학교), 비공식">' +
      '<span class="ic">🔍</span><input type="search" maxlength="100" autocomplete="off" spellcheck="false" ' +
      'placeholder="빠른 검색 — 제목·보낸 사람·거래처·초성(ㄱㅅㅅ)"></label></span>';
    const inp = td.querySelector("input");
    let timer = 0;
    inp.addEventListener("input", () => { markUsed(); clearTimeout(timer); timer = setTimeout(() => sendQ(inp.value), 200); });
    // 한 번도 써 보지 않았으면 칸 아래에 안내 말풍선 (누르면 칸으로, 한 번 쓰면 사라짐)
    getUsed((used) => {
      if (used || usedNow) return;
      const tip = document.createElement("span");
      tip.className = "tip";
      tip.textContent = "↑ 여기에 치면 바로 찾아요 · 띄어쓰기·초성(ㄱㅅㅅ)도 돼요";
      tip.addEventListener("click", () => inp.focus());
      td.querySelector(".wrap").appendChild(tip);
    });
    inp.addEventListener("keydown", (e) => {
      e.stopPropagation(); // 메일 화면의 단축키가 끼어들지 않게
      if (e.key === "Enter" && !e.isComposing) { e.preventDefault(); clearTimeout(timer); sendQ(inp.value, true); }
      if (e.key === "Escape" && inp.value) { inp.value = ""; clearTimeout(timer); sendQ(""); }
    });
    tool.after(td);
    // 칸이 나중에 붙었으면 이미 열린 탭 안 화면에도 알려 줌
    const f = quickFrame();
    if (f && f.contentWindow) try { f.contentWindow.postMessage({ kmhQuick: "hello" }, EXT_ORIGIN); } catch {}
  }
  window.addEventListener("message", (e) => {
    const f = quickFrame();
    if (!f || e.source !== f.contentWindow || e.origin !== EXT_ORIGIN) return;
    const d = e.data, inp = document.querySelector("td." + MARK + "-box input");
    if (!d || !inp) return;
    const first = readyWin !== f.contentWindow;
    readyWin = f.contentWindow; // 탭 안 화면에서 말이 왔으면 받을 준비가 된 것
    if (d.kmhQuick === "ready") post(f, { kmhQuick: "hello" });
    if (d.kmhQuick === "ready" || first) {
      // 위쪽 칸이 비어 있고 탭 안에 낱말이 있으면(메일 화면이 칸을 다시 그린 경우) 탭 쪽 낱말을 칸에 맞춤
      if (d.kmhQuick === "q" && typeof d.q === "string" && !inp.value) { inp.value = d.q; pendingEnter = false; return; }
      // 그 밖에는 탭이 뜨는 동안 더 친 글자와 Enter를 이제 넘겨 줌 (위쪽 칸이 기준)
      post(f, { kmhQuick: "setQ", q: inp.value });
      if (pendingEnter) post(f, { kmhQuick: "enter" });
      pendingEnter = false;
      return;
    }
    // 탭 안에서 낱말이 바뀌면(조건 모두 풀기 등) 위쪽 칸도 맞춤 — 치는 중이면 건드리지 않음
    if (d.kmhQuick === "q" && typeof d.q === "string" && document.activeElement !== inp) inp.value = d.q;
  });

  function ensure() {
    if (!document.head) return;
    addStyle();
    addTopButton();
    addToolButton();
    addQuickBox();
  }

  // 메일 화면은 늦게 그려지고 다시 그려지기도 하므로, 잠깐씩 확인해 버튼이 없으면 다시 붙임
  ensure();
  let n = 0;
  const t = setInterval(() => {
    ensure();
    if (++n > 30 && document.querySelector("td." + MARK + "-top") && document.querySelector("td." + MARK + "-tool")) clearInterval(t);
  }, 1000);
  setInterval(ensure, 10000);
})();
