// 처음 설치했을 때 한 번 뜨는 안내 화면
const send = async (m) => { try { return await chrome.runtime.sendMessage(m); } catch { return null; } };
document.getElementById("open").onclick = () => send({ type: "openMail" });
document.getElementById("test").onclick = async () => {
  const r = await send({ type: "testNotice" });
  document.getElementById("testRes").textContent =
    r && r.ok ? "오른쪽 아래에 알림 창이 떴는지 보세요." : "알림 창을 띄우지 못했습니다. 크롬을 다시 켠 뒤 해 보세요.";
};
