// 메일 탭 안에서 실행됩니다 (페이지와 같은 환경). 서버에는 아무 요청도 보내지 않습니다.
//
// 로그인 연장은 확장프로그램(background.js)이 몇 분마다 직접 합니다.
// 그런데 메일 탭이 열려 있으면, 탭 안의 타이머는 그 사실을 모르고 55분 뒤 "자동 로그아웃 안내" 창을 띄웁니다.
// 그래서 "로그인 자동 연장"을 켠 경우에만, 탭 안의 55분 타이머를 몇 분마다 처음으로 되돌려
// 이미 연장된 상태에서 쓸데없는 안내 창이 뜨지 않게 합니다.
(function () {
  if (window.top !== window) return;
  const EVERY_MS = 5 * 60 * 1000;

  function tick() {
    // 이 확장프로그램만 쓰는 이름 (다른 확장프로그램과 섞이지 않게)
    if (document.documentElement.dataset.kmhSchoolKeepalive !== "on") return;
    try {
      if (typeof window.resetTimeout === "function") window.resetTimeout();
    } catch {
      /* 페이지 구조가 바뀌었으면 조용히 넘어감 */
    }
  }

  setInterval(tick, EVERY_MS);
})();
