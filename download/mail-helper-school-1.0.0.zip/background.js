// 공직자통합메일도우미(학교) (비공식) - 백그라운드
importScripts("lib/idb.js", "lib/searchcore.js");

const BASE = "https://kmmbox.korea.kr";
const MAIL_HOME = "https://mail.korea.kr/";

const DEFAULTS = {
  intervalMin: 3,        // 새 메일 확인 간격(분)
  keepAlive: true,       // 로그인 자동 연장: 메일 탭을 닫아도 주기적으로 연장 (기본 켜짐 - 기관 보안 지침상 안 되면 각자 끔)
  extendEveryMin: 10,    // 연장 간격(분)
  nativeNotice: true,    // 오른쪽 아래 팝업 창과 함께 윈도우 기본 알림도 띄우기 (기본 켜짐)
  alertKeywords: [],     // 제목에 이 낱말이 있으면 ⭐ 중요 표시
  vipSenders: []         // 이 사람·기관이 보내면 ⭐ 중요 표시
};

// 오른쪽 아래 팝업 창 크기
const POP_W = 400;
const POP_H = 300;
const POP_MARGIN = 12;

async function getSettings() {
  const s = await chrome.storage.local.get("settings");
  return { ...DEFAULTS, ...(s.settings || {}) };
}

async function setupAlarms() {
  const s = await getSettings();
  await chrome.alarms.clearAll();
  const period = Math.max(1, Number(s.intervalMin) || 3);
  // 여러 PC가 같은 시각(예: 출근 직후)에 켜져도 요청이 한꺼번에 몰리지 않도록 첫 확인 시각을 무작위로 흩뜨림
  chrome.alarms.create("check", { periodInMinutes: period, delayInMinutes: 0.2 + Math.random() * period });
  // 화면 안 탭 상태 동기화용 (서버 요청 없음)
  chrome.alarms.create("sync", { periodInMinutes: 1, delayInMinutes: 0.1 });
  if (s.keepAlive) {
    const ext = Math.max(5, Number(s.extendEveryMin) || 10);
    chrome.alarms.create("extend", { periodInMinutes: ext, delayInMinutes: 0.5 + Math.random() * 2 });
  }
}

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

chrome.runtime.onInstalled.addListener(async (d) => {
  await setupAlarms();
  if (d && d.reason === "install") {
    // 처음 설치: 이미 열려 있는 메일 화면에도 버튼·빠른 검색 칸을 바로 붙이고 (새로 고침하지 않아도 되게),
    // 처음 쓰는 순서를 안내하는 화면을 한 번 띄움
    await attachToOpenTabs();
    try { await chrome.tabs.create({ url: "welcome.html" }); } catch {}
  }
});

// 크롬은 설치 전에 열려 있던 탭에는 확장프로그램 화면 코드를 붙이지 않으므로 직접 붙임 (처음 설치 때만.
// 업데이트 때는 예전 코드가 남아 있어 겹칠 수 있으므로 하지 않고, 메일 화면이 '새로 고침' 안내를 띄움)
async function attachToOpenTabs() {
  let tabs = [];
  try { tabs = await chrome.tabs.query({ url: ["https://kmmbox.korea.kr/*"] }); } catch { return; }
  for (const t of tabs) {
    try { await chrome.scripting.executeScript({ target: { tabId: t.id }, world: "MAIN", files: ["page-keepalive.js"] }); } catch {}
    if (/\/mail\/mainframe/.test(t.url || "")) {
      try { await chrome.scripting.executeScript({ target: { tabId: t.id }, files: ["mail-button.js"] }); } catch {}
    }
  }
}
chrome.runtime.onStartup.addListener(async () => {
  // 크롬을 새로 켜면 창 번호가 처음부터 다시 매겨지므로, 지난번 알림 창 번호와 목록은 버림
  // (안 그러면 엉뚱한 크롬 창을 알림 창으로 잘못 알아 알림이 안 뜨거나, 그 창을 닫을 때 목록이 지워짐)
  await chrome.storage.local.set({ alertWinId: null, popupMails: [] });
  await setupAlarms();
});

chrome.alarms.onAlarm.addListener(async (a) => {
  if (a.name === "check") {
    await sleep(Math.random() * 15000); // 매번 0~15초 흔들어 요청 시각 분산
    await checkMail();
  }
  if (a.name === "sync") { await syncPageFlag(); await resumeSyncIfStale(); }
  if (a.name === "extend") {
    await sleep(Math.random() * 15000);
    await extendLogin();
  }
});

// 메일 탭을 새로 고치거나 다시 로그인하면 설정 표시가 사라지므로, 로딩이 끝날 때마다 다시 알려 줌
chrome.tabs.onUpdated.addListener((tabId, info, tab) => {
  if (info.status === "complete" && tab.url && tab.url.startsWith("https://kmmbox.korea.kr/")) syncPageFlag();
});

// ---------- 서버 호출 ----------
class LoggedOutError extends Error {}
class ServerBusyError extends Error {}
class NetError extends Error {}   // 인터넷 끊김·서버에 닿지 않음 (로그인 풀림과 구분)

// 응답이 이 시간 넘게 없으면 기다리지 않고 멈춤 (한 요청이 멈춰 뒤의 요청이 모두 막히지 않게)
const TIMEOUT_MS = 20000;

async function findMailTab() {
  const tabs = await chrome.tabs.query({ url: ["https://kmmbox.korea.kr/*"] });
  return tabs.find((t) => t.url && !/login|logout/i.test(t.url)) || null;
}

// 응답 주소가 로그인·로그아웃 화면으로 넘어갔는지 (연장 주소 /loginextend.json 은 제외 - 이름에 login 이 들어 있음)
function isLoginPage(u) {
  let p = String(u || "");
  try { p = new URL(p).pathname; } catch {}
  return /login|logout/i.test(p.replace(/\/loginextend\.json$/i, ""));
}

function parseJson(text) {
  try {
    return JSON.parse(text);
  } catch {
    throw new LoggedOutError("JSON 아님 (로그인이 풀린 것으로 판단)");
  }
}

// 진단용: 마지막 요청이 어느 경로로 성공/실패했는지 기록
let lastApi = { path: "", via: "", directFail: "" };

// ---------- 요청 제한기 ----------
// 서버에 부담을 주지 않도록 모든 요청을 한 줄로 세워 하나씩 보냅니다.
//  - 요청과 요청 사이 최소 1.5초
//  - 1분에 최대 20번
const LIMIT = { minGapMs: 1500, perMinute: 20 };
let reqChain = Promise.resolve();
let lastReqAt = 0;
const reqTimes = [];

function throttled(fn) {
  const run = async () => {
    for (;;) {
      const now = Date.now();
      while (reqTimes.length && now - reqTimes[0] > 60000) reqTimes.shift();
      const gapWait = lastReqAt + LIMIT.minGapMs - now;
      const minuteWait = reqTimes.length >= LIMIT.perMinute ? reqTimes[0] + 60000 - now : 0;
      const wait = Math.max(gapWait, minuteWait);
      if (wait <= 0) break;
      await sleep(wait + 20);
    }
    lastReqAt = Date.now();
    reqTimes.push(lastReqAt);
    return fn();
  };
  const p = reqChain.then(run, run);
  reqChain = p.catch(() => {});
  return p;
}

function apiPost(path, params = {}) {
  return throttled(() => apiPostRaw(path, params));
}

// 시간 제한이 있는 요청 (본문을 다 받을 때까지 포함)
async function timedFetch(url, opt) {
  const ac = new AbortController();
  const timer = setTimeout(() => ac.abort(), TIMEOUT_MS);
  try {
    const r = await fetch(url, { ...opt, signal: ac.signal });
    return { ok: r.ok, status: r.status, url: r.url, text: await r.text() };
  } finally {
    clearTimeout(timer);
  }
}

// 1순위: 확장프로그램에서 바로 요청. 2순위: 열려 있는 메일 탭 안에서 요청.
async function apiPostRaw(path, params = {}, asText = false, tabOnly = false) {
  const body = asText ? null : new URLSearchParams(params || {}).toString();
  lastApi = { path, via: "", directFail: tabOnly ? "건너뜀" : "" };
  let netFail = false;
  if (!tabOnly) try {
    const r = await timedFetch(BASE + path, asText
      ? { method: "GET", credentials: "include" }
      : {
        method: "POST",
        credentials: "include",
        headers: { "X-Requested-With": "XMLHttpRequest", "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8" },
        body
      });
    if (r.ok && !isLoginPage(r.url)) {
      if (asText) { lastApi.via = "direct"; return r.text; }
      try {
        const j = JSON.parse(r.text);
        lastApi.via = "direct";
        return j;
      } catch {
        lastApi.directFail = "JSON 아님(" + r.text.slice(0, 40).replace(/\s+/g, " ") + ")";
      }
    } else if (r.status === 429 || r.status >= 500) {
      // 서버가 바쁘다는 응답: 다른 경로로 다시 묻지 않고 바로 멈춤
      throw new ServerBusyError("서버 응답 " + r.status);
    } else {
      lastApi.directFail = "HTTP " + r.status + (isLoginPage(r.url) ? " 로그인 페이지로 이동" : "");
    }
  } catch (e) {
    if (e instanceof ServerBusyError) throw e;
    // 응답이 없으면 서버가 느린 것: 탭으로 한 번 더 묻지 않고 멈춤
    if (e && e.name === "AbortError") throw new ServerBusyError("응답 없음(" + TIMEOUT_MS / 1000 + "초)");
    netFail = true;
    lastApi.directFail = "요청 오류: " + String(e && e.message || e);
  }

  const tab = await findMailTab();
  if (!tab) {
    if (netFail) throw new NetError("메일 서버에 연결하지 못함(" + lastApi.directFail + ")");
    throw new LoggedOutError("직접 요청 실패(" + lastApi.directFail + "), 메일 탭도 없음");
  }
  lastApi.via = "tab";
  const [res] = await chrome.scripting.executeScript({
    target: { tabId: tab.id },
    world: "MAIN",
    func: async (p, b, ms) => {
      const ac = new AbortController();
      const timer = setTimeout(() => ac.abort(), ms);
      try {
        const r = await fetch(p, b == null ? { method: "GET", signal: ac.signal } : {
          method: "POST",
          headers: { "X-Requested-With": "XMLHttpRequest", "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8" },
          body: b,
          signal: ac.signal
        });
        return { ok: r.ok, status: r.status, url: r.url, text: await r.text() };
      } catch (e) {
        return { err: e && e.name === "AbortError" ? "timeout" : "net" };
      } finally {
        clearTimeout(timer);
      }
    },
    args: [path, body, TIMEOUT_MS]
  });
  const out = res && res.result;
  if (out && out.err === "timeout") throw new ServerBusyError("응답 없음(" + TIMEOUT_MS / 1000 + "초)");
  if (out && out.err === "net") throw new NetError("메일 서버에 연결하지 못함(탭)");
  if (out && (out.status === 429 || out.status >= 500)) throw new ServerBusyError("서버 응답 " + out.status);
  if (!out || !out.ok || isLoginPage(out.url)) throw new LoggedOutError("탭 요청 실패");
  return asText ? out.text : parseJson(out.text);
}

// ---------- 로그인 자동 연장 ----------
// 메일 탭이 없어도, 확장프로그램이 몇 분마다 화면의 '이용 연장하기' 버튼과 같은 요청(/loginextend.json)을
// 직접 보내 서버 로그인을 유지합니다.
async function extendLogin() {
  const s = await getSettings();
  if (!s.keepAlive) return;
  const { loggedOut } = await chrome.storage.local.get("loggedOut");
  if (loggedOut) return; // 이미 풀린 세션은 연장할 수 없음
  try {
    let j = await apiPost("/loginextend.json");
    let ok = !!(j && j.result === true);
    // 확장프로그램에서 바로 보낸 연장이 거절되면(서버가 다른 곳에서 온 요청으로 볼 때),
    // 메일 탭이 열려 있으면 그 탭 안에서 '이용 연장하기'와 똑같이 한 번 더 보냄
    if (!ok && lastApi.via === "direct" && (await findMailTab())) {
      const first = JSON.stringify(j).slice(0, 40);
      j = await throttled(() => apiPostRaw("/loginextend.json", {}, false, true));
      ok = !!(j && j.result === true);
      lastApi.directFail = "직접 응답 " + first;
    }
    await chrome.storage.local.set({
      lastExtend: Date.now(), lastExtendOk: ok,
      extendDiag: (ok ? "" : "응답 " + JSON.stringify(j).slice(0, 60) + " / ") + "경로 " + lastApi.via + (lastApi.directFail ? " (직접 실패: " + lastApi.directFail + ")" : "")
    });
  } catch (e) {
    await chrome.storage.local.set({
      lastExtend: Date.now(), lastExtendOk: false,
      extendDiag: String(e && e.message || e)
    });
    if (e instanceof LoggedOutError) await checkMail(true); // 로그아웃 여부를 바로 확인해 알림
  }
  await syncPageFlag(); // 연장 성공·실패를 메일 탭에도 바로 알려 줌
}

// 메일 탭이 열려 있으면, 탭 안의 55분 안내 타이머가 연장 사실을 모르고 안내 창을 띄우거나
// 스스로 로그아웃하지 않도록 알려 줍니다. (서버 요청 없음)
// 자동 연장이 최근에 성공했을 때만 "켜짐"으로 알림 → 연장이 실패하고 있으면
// 메일 화면 원래의 '자동 로그아웃 안내'가 그대로 떠서 사용자가 알 수 있음
async function syncPageFlag() {
  const s = await getSettings();
  const { lastExtend = 0, lastExtendOk = false } = await chrome.storage.local.get(["lastExtend", "lastExtendOk"]);
  const everyMs = Math.max(5, Number(s.extendEveryMin) || 10) * 60e3;
  const on = !!s.keepAlive && lastExtendOk && Date.now() - lastExtend < everyMs * 2 + 2 * 60e3;
  const tabs = await chrome.tabs.query({ url: ["https://kmmbox.korea.kr/*"] });
  for (const t of tabs) {
    try {
      await chrome.scripting.executeScript({
        target: { tabId: t.id },
        world: "MAIN",
        // 다른 확장프로그램이 쓰는 이름과 섞이지 않게, 이 확장프로그램만 쓰는 이름을 씀
        func: (v) => { document.documentElement.dataset.kmhSchoolKeepalive = v ? "on" : "off"; },
        args: [on]
      });
    } catch {}
  }
}

// ---------- 메일 목록 모으기 (검색용) ----------
// 서버 부담을 줄이는 원칙
//  - 메일함별로 500통씩 나눠서 요청 (모든 메일함을 한 번에 묻는 무거운 요청은 쓰지 않음)
//  - 모든 요청은 위의 제한기를 거침 (한 번에 하나, 1.5초 간격, 1분 20번 이하)
//  - 전체 다시 모으기: 자동은 하루 한 번, 손으로는 30분에 한 번까지
//  - 오류가 나면 즉시 멈추고, 다시 시도까지 기다리는 시간을 점점 늘림
//  - 본문은 모으지 않음. 메일을 옮기거나 지우는 요청은 보내지 않음
const SYNC = {
  pageSize: 500,
  maxPagesPerFolder: 40,          // 메일함 하나에 최대 2만 통까지
  autoEveryMs: 24 * 3600e3,       // 자동 전체 맞춤: 하루 한 번
  manualGapMs: 30 * 60e3,         // 손으로 다시 모으기: 30분 간격
  staleMs: 90e3                   // 이 시간 넘게 소식이 없으면 중단된 것으로 보고 이어서 함
};
// 모으는 메일함: 받은(1), 보낸(4), 내게 쓴(8), 내가 만든 메일함(20)
const COLLECT_TYPES = new Set([1, 4, 8, 20]);
let syncRunning = false;

async function getSyncState() {
  const { syncState } = await chrome.storage.local.get("syncState");
  return syncState || { status: "none", backoff: 0 };
}
async function setSyncState(patch) {
  const cur = await getSyncState();
  const next = { ...cur, ...patch };
  await chrome.storage.local.set({ syncState: next });
  return next;
}

async function discoverFolders() {
  const out = [];
  const walk = async (list, depth) => {
    for (const f of Array.isArray(list) ? list : []) {
      const at = Number(f.actionType);
      if (COLLECT_TYPES.has(at)) out.push({ id: f.id, text: clean(f.text), actionType: at, folderType: f.folderType ?? 0, total: Number(f.totalMsgNum) || 0 });
      // '내 메일함'(10) 아래와, 하위 메일함이 있는 내 메일함은 펼쳐 봄
      if ((at === 10 || at === 20) && f.leaf === false && depth < 3) {
        const kids = Array.isArray(f.children) && f.children.length ? f.children : await apiPost("/folder/treelist/mailbox.json", { node: f.id });
        await walk(kids, depth + 1);
      }
    }
  };
  await walk(await apiPost("/folder/treelist/mailbox.json"), 0);
  return out;
}

async function collectFolder(folder, onPage) {
  const recs = [];
  for (let p = 0; p < SYNC.maxPagesPerFolder; p++) {
    const j = await apiPost("/mail/list/mailbox.json", {
      start: p * SYNC.pageSize, limit: SYNC.pageSize, sort: "timeMillis", dir: "DESC", method: "mailbox",
      allFolder: false, folderUid: folder.id, folderType: folder.folderType
    });
    if (!j || !Array.isArray(j.contents)) throw new LoggedOutError("목록 응답이 이상함");
    j.contents.forEach((m) => recs.push(KmnSearch.toRecord(m, folder)));
    await onPage(recs.length, Number(j.totalCount) || folder.total);
    if (j.contents.length < SYNC.pageSize || recs.length >= (Number(j.totalCount) || Infinity)) break;
  }
  return recs;
}

async function runSync(reason) {
  if (syncRunning) return;
  syncRunning = true;
  const st0 = await getSyncState();
  // 끊겼던 모으기(잠듦·로그인 풀림·오류)는 다 모은 메일함을 건너뛰고 이어서 함
  const resuming = ["running", "paused", "error"].includes(st0.status) && Array.isArray(st0.doneIds);
  const doneIds = resuming ? st0.doneIds : [];
  try {
    await setSyncState({ status: "running", reason, startedAt: resuming && st0.startedAt ? st0.startedAt : Date.now(), heartbeat: Date.now(), error: "", doneIds });
    const folders = await discoverFolders();
    await setSyncState({ folders: folders.map((f) => ({ id: f.id, text: f.text, total: f.total, got: doneIds.includes(f.id) ? f.total : 0 })) });

    for (const f of folders) {
      if (doneIds.includes(f.id)) continue;
      const recs = await collectFolder(f, async (got, total) => {
        const s = await getSyncState();
        const list = (s.folders || []).map((x) => (x.id === f.id ? { ...x, got, total } : x));
        await setSyncState({ folders: list, current: f.text, heartbeat: Date.now() });
      });
      await KmnDB.replaceFolder(f.id, recs);
      doneIds.push(f.id);
      await setSyncState({ doneIds, heartbeat: Date.now() });
    }
    await KmnDB.removeFoldersExcept(folders.map((f) => f.id));
    const n = await KmnDB.count();
    await setSyncState({ status: "done", current: "", lastFullSync: Date.now(), count: n, backoff: 0, pausedUntil: 0, doneIds: [] });
  } catch (e) {
    const s = await getSyncState();
    if (e instanceof LoggedOutError) {
      // 로그인이 풀린 경우: 기다림을 늘리지 않고 멈춤. 다시 로그인되면 저절로 이어서 모음
      await setSyncState({ status: "paused", error: "로그인이 필요합니다", heartbeat: Date.now(), pausedUntil: Date.now() + 5 * 60e3 });
    } else if (e instanceof NetError) {
      // 인터넷이 끊긴 경우: 마찬가지로 멈췄다가 연결되면 이어서 모음
      await setSyncState({ status: "paused", error: "메일 서버에 연결하지 못했습니다", heartbeat: Date.now(), pausedUntil: Date.now() + 5 * 60e3 });
    } else {
      const level = Math.min((s.backoff || 0) + 1, 6);
      const waitMs = Math.min(5 * 60e3 * Math.pow(2, level - 1), 6 * 3600e3); // 5분, 10분, 20분 … 최대 6시간
      await setSyncState({ status: "error", error: String(e && e.message || e), backoff: level, pausedUntil: Date.now() + waitMs, heartbeat: Date.now() });
    }
  } finally {
    syncRunning = false;
  }
}

// 검색 화면이 열릴 때(auto) 또는 '목록 모으기' 버튼(manual)
async function requestSync(kind) {
  const s = await getSyncState();
  const now = Date.now();
  if (syncRunning) return { ok: true, started: false, why: "running" };
  // 오류 뒤 쉬는 시간은 지킴 (로그인·연결 문제로 멈춘 것은 다시 로그인했으면 바로 이어서 할 수 있음)
  if (s.status === "error" && s.pausedUntil && now < s.pausedUntil) return { ok: false, why: "backoff", until: s.pausedUntil };
  const { loggedOut } = await chrome.storage.local.get("loggedOut");
  if (loggedOut) return { ok: false, why: "login" };
  const interrupted = s.status === "running" || s.status === "paused" || s.status === "error";
  if (kind === "manual") {
    if (!interrupted && s.lastFullSync && now - s.lastFullSync < SYNC.manualGapMs) return { ok: false, why: "tooSoon", until: s.lastFullSync + SYNC.manualGapMs };
  } else {
    const due = !s.lastFullSync || now - s.lastFullSync > SYNC.autoEveryMs;
    if (!due && !interrupted) return { ok: true, started: false, why: "fresh" };
    if (!s.lastFullSync && !interrupted) return { ok: true, started: false, why: "needFirst" }; // 첫 모으기는 사용자가 버튼으로 시작
  }
  runSync(kind); // 기다리지 않음 (진행 상황은 storage로 알림)
  return { ok: true, started: true };
}

// 서비스 워커가 중간에 잠들어 모으기가 끊겼으면 이어서 함 (1분마다 확인, 서버 요청 없음)
// 멈춘 모으기를 이어서 함 (1분마다 확인, 확인 자체는 서버 요청 없음)
//  - 서비스 워커가 중간에 잠들어 끊긴 경우: 바로
//  - 로그인 풀림·인터넷 끊김으로 멈춘 경우: 다시 로그인된 것이 확인되면 (5분 간격까지만)
//  - 오류로 쉬는 중인 경우: 늘어난 기다림(5분→10분→…→6시간)이 끝나면 한 번 더
async function resumeSyncIfStale() {
  if (syncRunning) return;
  const s = await getSyncState();
  const now = Date.now();
  if (s.status === "running" && now - (s.heartbeat || 0) > SYNC.staleMs) { runSync("resume"); return; }
  if ((s.status === "paused" || s.status === "error") && s.pausedUntil && now >= s.pausedUntil) {
    const { loggedOut } = await chrome.storage.local.get("loggedOut");
    if (!loggedOut) runSync("resume");
  }
}

// 새 메일 확인 때 이미 받아 온 최근 메일을 검색 목록에도 넣음 (추가 요청 없음)
async function upsertRecent(mails, inbox) {
  const s = await getSyncState();
  if (!s.lastFullSync || !mails.length) return;
  const folder = { id: inbox.id, text: clean(inbox.text) || "받은메일함", actionType: 1 };
  try {
    await KmnDB.putMany(mails.map((m) => KmnSearch.toRecord(m, folder)));
    await chrome.storage.local.set({ dbTouched: Date.now() }); // 열려 있는 검색 화면이 목록을 다시 읽도록
  } catch {}
}

// ---------- 새 메일 확인 ----------
const clean = (str) => KmnSearch.clean(str);

// 알람과 '지금 확인'이 겹쳐도 한 번만 확인 (같은 메일을 두 번 알리지 않게)
let checking = null;
function checkMail(force = false) {
  if (checking) return checking;
  checking = checkMailOnce(force).finally(() => { checking = null; });
  return checking;
}

async function checkMailOnce(force) {
  const st = await chrome.storage.local.get(["lastMaxUid", "loggedOut", "inboxId", "lastTotal", "unread", "netFails"]);
  try {
    const folders = await apiPost("/folder/treelist/mailbox.json");
    const inbox = (Array.isArray(folders) ? folders : []).find((f) => Number(f.actionType) === 1 || f.text === "받은메일함");
    if (!inbox) throw new LoggedOutError("받은메일함을 찾지 못함");

    const unread = Number(inbox.msgNum) || 0;
    const total = Number(inbox.totalMsgNum) || 0;
    await setBadge(unread);

    // 받은메일함 전체·안읽은 개수가 그대로면 목록은 요청하지 않음 (요청 1번으로 끝)
    const changed = st.lastMaxUid == null || total !== st.lastTotal || unread > (st.unread ?? 0);
    if (!force && !changed) {
      if (st.loggedOut) await clearLogoutNotice();
      await chrome.storage.local.set({
        loggedOut: false, unread, lastTotal: total, lastCheck: Date.now(), inboxId: inbox.id, lastError: null, netFails: 0,
        checkDiag: "경로 " + lastApi.via + (lastApi.directFail ? " (직접 실패: " + lastApi.directFail + ")" : "")
      });
      if (st.loggedOut) resumeSyncIfStale(); // 다시 로그인됨 → 멈췄던 목록 모으기를 이어서
      return;
    }

    const list = await apiPost("/mail/list/mailbox.json", {
      start: 0, limit: 20, sort: "timeMillis", dir: "DESC", method: "mailbox",
      allFolder: false, folderUid: inbox.id, folderType: inbox.folderType ?? 0
    });
    const mails = Array.isArray(list.contents) ? list.contents : [];
    const maxUid = mails.reduce((m, x) => Math.max(m, Number(x.mailUid) || 0), 0);

    let fresh = [];
    if (st.lastMaxUid == null) {
      // 첫 확인: 기준점만 잡고 알리지 않음
      await chrome.storage.local.set({ lastMaxUid: maxUid });
    } else {
      fresh = mails.filter((m) => Number(m.mailUid) > st.lastMaxUid && !m.isSeen);
      if (maxUid > st.lastMaxUid) await chrome.storage.local.set({ lastMaxUid: maxUid });
    }

    // 상태를 먼저 저장해서, 알림 창에서 문제가 나도 메일 수·목록은 맞게 보이게 함
    await chrome.storage.local.set({
      checkDiag: "경로 " + lastApi.via + (lastApi.directFail ? " (직접 실패: " + lastApi.directFail + ")" : ""),
      loggedOut: false, unread, lastTotal: total, lastCheck: Date.now(), inboxId: inbox.id, lastError: null, netFails: 0,
      recent:mails.slice(0, 5).map((m) => ({ from: clean(m.adrFrom), subject: clean(m.subject), time: m.timeMillis, seen: !!m.isSeen }))
    });
    if (st.loggedOut) { await clearLogoutNotice(); resumeSyncIfStale(); } // 다시 로그인됨 → 멈췄던 목록 모으기를 이어서
    await upsertRecent(mails, inbox);
    if (fresh.length) {
      try { await notifyNew(fresh, unread); }
      catch (err) { await chrome.storage.local.set({ lastError: "알림 창: " + String(err && err.message || err) }); }
    }
  } catch (err) {
    let e = err;
    if (e instanceof NetError) {
      // 인터넷이 끊겼거나(절전에서 막 깨어남 등) 서버에 닿지 않음: 로그인 풀림으로 알리지 않음.
      // 다만 인터넷은 되는데 연결 오류가 두 번 이어지면(로그인 화면이 다른 주소로 넘어가 읽지 못하는 경우 등)
      // 로그인이 풀린 것으로 봄
      const n = (st.netFails || 0) + 1;
      const offline = typeof navigator !== "undefined" && navigator.onLine === false;
      if (offline || n < 2) {
        await chrome.storage.local.set({
          netFails: n, lastCheck: Date.now(),
          lastError: "메일 확인: " + (offline ? "인터넷 연결이 끊겨 있습니다" : e.message)
        });
        return;
      }
      e = new LoggedOutError(e.message);
    }
    if (e instanceof LoggedOutError) {
      await chrome.action.setBadgeBackgroundColor({ color: "#d93025" });
      await chrome.action.setBadgeText({ text: "!" });
      await chrome.storage.local.set({ loggedOut: true, lastCheck: Date.now() });
      if (!st.loggedOut) await notifyLogout();
    } else {
      await chrome.storage.local.set({ lastError: "메일 확인: " + String(e && e.message || e), lastCheck: Date.now() });
    }
  }
}

async function setBadge(n) {
  await chrome.action.setBadgeBackgroundColor({ color: "#1a73e8" });
  await chrome.action.setBadgeText({ text: n > 0 ? (n > 99 ? "99+" : String(n)) : "" });
}

// ---------- 알림: 오른쪽 아래 팝업 창 ----------
// 팝업 창은 사용자가 '메일 열기'나 '닫기'를 눌러야 닫힙니다 (저절로 사라지지 않음).
// 창이 떠 있는 동안 새 메일이 더 오면 같은 창의 목록에 추가합니다.

async function notifyNew(fresh, unread) {
  const s = await getSettings();
  const items = fresh.map((m) => {
    const it = { id: String(m.mailUid), from: clean(m.adrFrom), subject: clean(m.subject), time: m.timeMillis, folderUid: m.folderUid };
    // 키워드·중요 발신자 표시 (이 PC 안에서만 판단)
    const hit = KmnSearch.alertMatch(
      { s: it.subject, a: it.from, e: clean(m.adrFromTooltip) },
      s.alertKeywords, s.vipSenders
    );
    if (hit) it.star = hit.vip ? "중요한 분: " + hit.vip : "키워드: " + hit.keyword;
    return it;
  });

  const { popupMails = [] } = await chrome.storage.local.get("popupMails");
  const known = new Set(popupMails.map((m) => m.id));
  const merged = [...items.filter((m) => !known.has(m.id)), ...popupMails].slice(0, 20);
  await chrome.storage.local.set({ popupMails: merged, popupUnread: unread });
  await showPopup();

  if (s.nativeNotice) {
    const m = items.find((x) => x.star) || items[0];
    chrome.notifications.create("mail-" + Date.now(), {
      type: "basic",
      iconUrl: "icons/icon128.png",
      title: (m.star ? "⭐ " : "") + (items.length > 1 ? "새 메일 " + items.length + "통" : "새 메일: " + (m.from || "보낸 사람 없음")),
      message: m.subject || "(제목 없음)",
      contextMessage: "안 읽은 메일 " + unread + "통",
      priority: 2
    });
  }
}

async function notifyLogout() {
  await chrome.storage.local.set({ popupLogout: true });
  await showPopup();
}

async function clearLogoutNotice() {
  await chrome.storage.local.set({ popupLogout: false });
  // 로그아웃 안내만 떠 있던 창이면 다시 로그인했을 때 닫아 줌
  const { popupMails = [] } = await chrome.storage.local.get("popupMails");
  const winId = await findAlertWindow();
  if (winId != null && popupMails.length === 0) {
    try { await chrome.windows.remove(winId); } catch {}
  }
}

// 지금 떠 있는 알림 창 찾기: 창 번호만 믿지 않고 실제로 alert.html이 열린 창인지 확인
async function findAlertWindow() {
  const url = chrome.runtime.getURL("alert.html");
  if (chrome.runtime.getContexts) {
    try {
      const ctx = await chrome.runtime.getContexts({ contextTypes: ["TAB"], documentUrls: [url] });
      if (ctx.length && ctx[0].windowId >= 0) return ctx[0].windowId;
    } catch {}
  }
  // 방금 만들어 아직 화면을 읽는 중인 창, 또는 옛 크롬:
  // 저장해 둔 번호의 창이 알림 창 크기의 팝업 창일 때만 알림 창으로 봄
  const { alertWinId } = await chrome.storage.local.get("alertWinId");
  if (!alertWinId) return null;
  try {
    const w = await chrome.windows.get(alertWinId);
    return w.type === "popup" && Math.abs(w.width - POP_W) < 60 ? w.id : null;
  } catch {
    return null;
  }
}

async function workArea() {
  try {
    const displays = await chrome.system.display.getInfo();
    const d = displays.find((x) => x.isPrimary) || displays[0];
    return d.workArea; // 작업표시줄을 뺀 영역
  } catch {
    return null;
  }
}

// 알림 창을 동시에 두 번 띄우지 않도록 (새 메일과 로그아웃 안내가 겹칠 때)
let popupBusy = Promise.resolve();
function showPopup() {
  const p = popupBusy.then(showPopupOnce, showPopupOnce);
  popupBusy = p.catch(() => {});
  return p;
}

async function showPopupOnce() {
  const existing = await findAlertWindow();
  if (existing != null) {
    try {
      // 이미 떠 있으면 내용만 갱신(alert.js가 저장소 변경을 감지)하고 다시 앞으로
      await chrome.windows.update(existing, { focused: true, drawAttention: true });
      await chrome.storage.local.set({ alertWinId: existing });
      return;
    } catch {
      /* 그 사이 닫혔음 → 새로 띄움 */
    }
  }

  const wa = await workArea();
  const plain = { url: "alert.html", type: "popup", width: POP_W, height: POP_H, focused: true };
  if (!wa) {
    const w = await chrome.windows.create(plain);
    await chrome.storage.local.set({ alertWinId: w.id });
    return;
  }

  const left = wa.left + wa.width - POP_W - POP_MARGIN;
  const finalTop = wa.top + wa.height - POP_H - POP_MARGIN;
  // 크롬은 창의 절반 이상이 화면 밖이면 만들지 않으므로, 40% 아래에서 시작해 위로 올림
  const startTop = finalTop + Math.round(POP_H * 0.4);

  let w;
  try {
    w = await chrome.windows.create({ ...plain, left, top: startTop });
  } catch {
    // 위치 지정이 거부되면: 일단 띄우고 오른쪽 아래로 옮김
    w = await chrome.windows.create(plain);
    await chrome.storage.local.set({ alertWinId: w.id });
    try { await chrome.windows.update(w.id, { left, top: finalTop, drawAttention: true }); } catch {}
    return;
  }
  await chrome.storage.local.set({ alertWinId: w.id });

  // 아래에서 위로 슬라이드
  const steps = 10;
  for (let i = 1; i <= steps; i++) {
    const t = 1 - Math.pow(1 - i / steps, 3); // 끝에서 부드럽게 멈춤
    const top = Math.round(startTop + (finalTop - startTop) * t);
    try { await chrome.windows.update(w.id, { top, left }); } catch { return; }
    await sleep(18);
  }
  try { await chrome.windows.update(w.id, { drawAttention: true }); } catch {}
}

chrome.windows.onRemoved.addListener(async (winId) => {
  const { alertWinId } = await chrome.storage.local.get("alertWinId");
  if (alertWinId != null && winId === alertWinId) {
    // 사용자가 닫은 것 = 확인함. 목록 비우기
    await chrome.storage.local.set({ alertWinId: null, popupMails: [], popupLogout: false });
  }
});

// ---------- 메일 열기 ----------
// 최소화된 창이면 먼저 원래 크기로 되살린 뒤(최대화였으면 최대화로) 맨 앞으로 가져옴
async function bringToFront(winId) {
  try {
    const w = await chrome.windows.get(winId);
    if (w.state === "minimized") {
      const wa = await workArea();
      const wasMax = wa && w.width >= wa.width - 20 && w.height >= wa.height - 20;
      await chrome.windows.update(winId, { state: wasMax ? "maximized" : "normal" });
      await sleep(80);
    }
    await chrome.windows.update(winId, { focused: true });
  } catch {}
}

// 이미 열려 있는 메일 탭은 앞으로 가져오기만 하면 새 메일이 목록에 안 보이므로,
// 메일 화면 왼쪽의 '받은메일함'을 누른 것과 똑같이 목록을 다시 불러옴 (요청 1번, 사용자가 누르는 것과 같음)
// 메일을 읽거나 쓰는 중(목록이 안 보임)이면 쓰던 내용이 사라지지 않게 건드리지 않음
async function refreshInbox(tab) {
  if (!/\/mail\/mainframe/.test(tab.url || "")) return;
  try {
    await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      world: "MAIN",
      func: () => {
        try {
          const W = window;
          if (!W.FolderTreePanel || !W.MailListPanel || !W.MailListPanel.gridPanel || !W.Ext) return "noapp";
          const g = W.MailListPanel.gridPanel.el && W.MailListPanel.gridPanel.el.dom;
          if (!g || !g.offsetParent) return "busy";
          let inbox = null;
          W.FolderTreePanel.root.cascade((n) => { if (!inbox && Number(n.attributes.actionType) === 1) inbox = n; });
          if (!inbox) return "noinbox";
          W.FolderTreePanel.fireEvent("click", inbox, W.Ext.EventObject);
          return "ok";
        } catch (e) {
          return "err";
        }
      }
    });
  } catch {}
}

async function openMail() {
  const tab = await findMailTab();
  if (tab) {
    await chrome.tabs.update(tab.id, { active: true });
    await bringToFront(tab.windowId);
    await refreshInbox(tab);
    return;
  }

  // 메일 탭이 없으면(탭을 닫고 자동 연장으로 쓰는 경우) 일반 크롬 창에 새 탭으로 열고 그 창을 앞으로
  let win = null;
  try { win = await chrome.windows.getLastFocused({ windowTypes: ["normal"] }); } catch {}
  if (win && win.id != null) {
    await chrome.tabs.create({ windowId: win.id, url: MAIL_HOME, active: true });
    await bringToFront(win.id);
  } else {
    await chrome.windows.create({ url: MAIL_HOME, type: "normal", focused: true, state: "maximized" });
  }
}

// ---------- 메일 화면 검색으로 넘기기 (메일본문·첨부이름) ----------
// 본문은 이 PC에 모으지 않으므로, 공직자통합메일 화면의 검색칸에 낱말·검색 범위·기간을 넣고
// 사용자가 돋보기를 누른 것과 똑같이 검색을 한 번 실행함 (요청 1번)
const SITE_FIELD = { all: "subject", subject: "subject", body: "content", from: "adrFrom", to: "adrTo", attach: "attachName" };
const siteDays = (d) => (!d ? 0 : d <= 7 ? 7 : d <= 31 ? 30 : d <= 92 ? 90 : d <= 183 ? 180 : 365);

function runSiteSearch(q, fieldCmd, dayCmd) {
  try {
    const W = window;
    if (!W.Ext || !W.Ext.getCmp) return "noapp";
    const t = W.Ext.getCmp("r3-mail-search-textfield");
    if (!t || !W.MailListPanel || !W.MailListPanel.gridPanel) return "noapp";
    const gridDom = () => W.MailListPanel.gridPanel.el && W.MailListPanel.gridPanel.el.dom;
    let g = gridDom();
    if (!g || !g.offsetParent) {
      // '빠른 검색' 탭을 보고 있으면 메일 목록 탭으로 돌아가서 찾음
      const M = W.Ext.getCmp("r3-tap-wrap");
      const a = M && M.getActiveTab && M.getActiveTab();
      if (a && a.id === "kmn-quick") { M.setActiveTab(M.getItem("maillist") || M.items.itemAt(0)); g = gridDom(); }
    }
    if (!g || !g.offsetParent) return "busy"; // 메일을 읽거나 쓰는 중: 쓰던 내용이 사라지지 않게 건드리지 않음
    const setCycle = (id, cmd) => {
      const c = W.Ext.getCmp(id);
      if (!c || !c.menu || !c.menu.items) return;
      const it = c.menu.items.items.find((i) => String(i.command) === String(cmd));
      if (it) c.setActiveItem(it);
    };
    setCycle("r3-mail-search-menu", fieldCmd);
    setCycle("r3-mail-search-date", dayCmd);
    t.setValue(q);
    t.onTrigger2Click();
    return "ok";
  } catch (e) {
    return "err";
  }
}

async function serverSearch(q, field, days, preferTab) {
  q = String(q || "").trim().slice(0, 100);
  if (!q) return "empty";
  const fieldCmd = SITE_FIELD[field] || "subject";
  const dayCmd = siteDays(Number(days) || 0);
  // '빠른 검색' 탭에서 눌렀으면 바로 그 메일 화면에서 찾음
  let tab = preferTab && /\/mail\/mainframe/.test(preferTab.url || "") ? preferTab : null;
  if (!tab) [tab] = await chrome.tabs.query({ url: BASE + "/mail/mainframe*" });
  const created = !tab;
  if (tab) {
    await chrome.tabs.update(tab.id, { active: true });
    await bringToFront(tab.windowId);
  } else {
    // 메일 목록 화면이 없으면 새 탭으로 열고, 화면이 다 뜰 때까지 기다림 (최대 30초)
    let win = null;
    try { win = await chrome.windows.getLastFocused({ windowTypes: ["normal"] }); } catch {}
    tab = win && win.id != null
      ? await chrome.tabs.create({ windowId: win.id, url: BASE + "/mail/mainframe.do", active: true })
      : (await chrome.windows.create({ url: BASE + "/mail/mainframe.do", type: "normal", focused: true, state: "maximized" })).tabs[0];
    if (win) await bringToFront(win.id);
  }
  for (let i = 0; i < 60; i++) {
    let res = "noapp";
    try {
      const t = await chrome.tabs.get(tab.id);
      if (/login|logout/i.test(t.url || "")) return "login";
      if (t.status === "complete") {
        const [r] = await chrome.scripting.executeScript({
          target: { tabId: tab.id }, world: "MAIN", func: runSiteSearch, args: [q, fieldCmd, dayCmd]
        });
        res = r && r.result;
      }
    } catch (e) {
      if (/No tab/i.test(String(e && e.message))) return "closed";
    }
    // 막 연 탭은 목록이 그려지기 전이라 'busy'로 보일 수 있어 조금 더 기다림
    if (res === "busy" && created && i < 40) res = "noapp";
    if (res !== "noapp") return res || "err";
    await sleep(500);
  }
  return "timeout";
}

// ---------- 메일 화면 안 '🔍 빠른 검색' 탭 ----------
// 메일 화면의 탭 묶음(받은메일함·메일보기·메일쓰기)에 탭 하나를 더하고, 그 안에 검색 화면(search.html?embed=1)을 띄움.
// 화면만 바꾸며 서버에는 요청하지 않음.
const QUICK_TITLE = "🔍 빠른 검색";

function injectQuickTab(src, hasQ, title) {
  try {
    const W = window, Ext = W.Ext;
    const M = Ext && Ext.getCmp && Ext.getCmp("r3-tap-wrap");
    if (!M || !M.add || !M.setActiveTab) return "noapp";
    let t = Ext.getCmp("kmn-quick");
    if (t) {
      // 이미 있으면 낱말만 바꿔 줌 (주소의 # 뒤만 바뀌므로 화면을 다시 읽지 않음)
      const f = t.body && t.body.dom && t.body.dom.querySelector("iframe");
      if (f && hasQ) f.src = src;
    } else {
      t = M.add({
        id: "kmn-quick", title, closable: true, layout: "fit", border: false,
        html: '<iframe src="' + src.replace(/"/g, "&quot;") + '" title="빠른 검색" ' +
          'style="display:block;width:100%;height:100%;border:0;background:#fff"></iframe>'
      });
    }
    M.setActiveTab(t);
    return "ok";
  } catch (e) {
    return "err";
  }
}

// noFocus: 메일 화면 위쪽 검색칸에서 치는 중이면, 탭 안 화면이 글자 입력 자리를 빼앗지 않게 (&nf=1)
async function openQuickTab(tab, q, noFocus) {
  q = String(q || "").trim().slice(0, 100);
  if (!tab || !/\/mail\/mainframe/.test(tab.url || "")) return "noapp";
  const src = chrome.runtime.getURL("search.html") + "?embed=1" +
    (q || noFocus ? "#q=" + encodeURIComponent(q) + "&t=" + Date.now() + (noFocus ? "&nf=1" : "") : "");
  try {
    const [r] = await chrome.scripting.executeScript({
      target: { tabId: tab.id }, world: "MAIN", func: injectQuickTab, args: [src, !!q || !!noFocus, QUICK_TITLE]
    });
    return (r && r.result) || "err";
  } catch {
    return "err";
  }
}

// 검색 결과를 메일 화면의 '메일보기' 탭에서 열기 (메일 목록에서 메일을 누른 것과 같음)
// 메일쓰기 탭이 떠 있으면 쓰던 내용을 건드리지 않도록 열지 않고 새 창으로 엶
function openInMailView(uid, fuid, sent) {
  try {
    const W = window, Ext = W.Ext;
    if (!W.MailViewPanel || !W.MailViewPanel.init || !W.MailViewPanel.show) return "noapp";
    const M = Ext && Ext.getCmp && Ext.getCmp("r3-tap-wrap");
    const w = M && M.getItem && M.getItem("mailwrite");
    const wTab = w && M.getTabEl && M.getTabEl(w);
    if (wTab && wTab.offsetParent) return "writing";
    W.MailViewPanel.show();
    W.MailViewPanel.init(uid, fuid, sent ? "outbox" : "inbox", W.MailListPanel && W.MailListPanel.lastCfg);
    return "ok";
  } catch (e) {
    return "err";
  }
}

function openMailPopup(uid) {
  // 메일 화면의 '새 창으로 보기'(mainframe/popup)는 메일 목록 화면에서 연 창이어야만 동작하므로,
  // 그 창이 안에 띄우는 메일 내용 화면(view.do)을 바로 엽니다.
  const url = BASE + "/mail/view.do?mailUid=" + uid + "&pageLayout=0&popup=1&blockedLevel=3";
  return chrome.windows.create({ url, type: "popup", width: 960, height: 820, focused: true });
}

// 따로 연 '메일 검색·정리' 화면 (크게 보기, 툴바 아이콘)
async function openSearchPage(msg, sender) {
  const base = chrome.runtime.getURL("search.html");
  const q = String(msg.q || "").slice(0, 100);
  const hash = msg.settings ? "#settings=" + Date.now() : q ? "#q=" + encodeURIComponent(q) + "&t=" + Date.now() : "";
  const url = base + hash;
  const [t] = (await chrome.tabs.query({ url: base + "*" })).filter((x) => !/[?&]embed=/.test(x.url || ""));
  if (t) {
    await chrome.tabs.update(t.id, hash ? { active: true, url } : { active: true });
    await bringToFront(t.windowId);
  } else {
    // 메일 화면에서 눌렀으면 그 탭 바로 옆에 열기
    const opt = { url };
    if (sender && sender.tab) { opt.index = sender.tab.index + 1; opt.windowId = sender.tab.windowId; }
    await chrome.tabs.create(opt);
  }
}

chrome.notifications.onClicked.addListener(async (id) => {
  chrome.notifications.clear(id);
  await openMail();
});

chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  // 어떤 경우에도 답을 꼭 돌려줌: 처리 중 오류가 나거나 모르는 요청이어도
  // 보낸 화면에 "답 없이 연결이 끊겼다"는 오류가 남지 않게
  let answered = false;
  const reply = sendResponse;
  sendResponse = (v) => { if (!answered) { answered = true; try { reply(v); } catch {} } };
  (async () => {
    try { await handleMessage(msg, _sender, sendResponse); }
    catch (err) { console.warn("메시지 처리 오류", msg && msg.type, err); sendResponse({ ok: false, error: String(err && err.message || err) }); }
    finally { sendResponse(undefined); }
  })();
  return true;
});

async function handleMessage(msg, _sender, sendResponse) {
  {
    if (!msg || typeof msg !== "object") return;
    if (msg.type === "checkNow") { await checkMail(true); sendResponse(await chrome.storage.local.get(null)); }
    else if (msg.type === "openMail") { await openMail(); sendResponse(true); }
    else if (msg.type === "settingsChanged") { await setupAlarms(); await syncPageFlag(); sendResponse(true); }
    else if (msg.type === "syncRequest") { sendResponse(await requestSync(msg.kind === "manual" ? "manual" : "auto")); }
    else if (msg.type === "syncClear") {
      if (syncRunning) { sendResponse({ ok: false, why: "running" }); return; }
      await KmnDB.clearAll();
      await chrome.storage.local.set({ syncState: { status: "none", backoff: 0 } });
      sendResponse({ ok: true });
    }
    else if (msg.type === "openSearch") {
      // 팝업의 '⭐ 중요 메일 알림 설정'에서 오면 설정 창을 바로 열어 줌
      await openSearchPage(msg, _sender);
      sendResponse(true);
    }
    else if (msg.type === "openQuickTab") {
      // 메일 화면의 '빠른 검색'·'메일 검색·정리': 메일 화면 안 탭으로 (안 되면 따로 연 화면으로)
      const r = await openQuickTab(_sender && _sender.tab, msg.q, !!msg.nf);
      if (r !== "ok" && !msg.nf) await openSearchPage(msg, _sender);
      sendResponse({ result: r });
    }
    else if (msg.type === "serverSearch") {
      sendResponse({ result: await serverSearch(msg.q, msg.field, msg.days, _sender && _sender.tab) });
    }
    else if (msg.type === "openMailItem") {
      // 검색 결과에서 메일 한 통 열기: '빠른 검색' 탭 안이면 메일보기 탭에서, 아니면 새 창으로
      const uid = Number(msg.mailUid);
      if (!uid) { sendResponse(false); return; }
      const tab = _sender && _sender.tab;
      if (msg.inView && tab && /\/mail\/mainframe/.test(tab.url || "")) {
        let r = "err";
        try {
          const [x] = await chrome.scripting.executeScript({
            target: { tabId: tab.id }, world: "MAIN", func: openInMailView, args: [uid, Number(msg.folderUid) || msg.folderUid, !!msg.sent]
          });
          r = (x && x.result) || "err";
        } catch {}
        if (r === "ok") { sendResponse({ result: "view" }); return; }
      }
      await openMailPopup(uid);
      sendResponse({ result: "popup" });
    }
    else if (msg.type === "testNotice") {
      const { unread = 0 } = await chrome.storage.local.get("unread");
      try {
        await notifyNew([{ mailUid: "test-" + Date.now(), adrFrom: "테스트", subject: "알림이 이렇게 뜹니다", timeMillis: Date.now() }], unread);
        sendResponse({ ok: true });
      } catch (err) {
        const msgText = String(err && err.message || err);
        await chrome.storage.local.set({ lastError: "알림 창: " + msgText });
        sendResponse({ ok: false, error: msgText });
      }
    }
  }
}
