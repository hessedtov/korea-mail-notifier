// 메일 검색·정리 화면. 모은 목록(IndexedDB)을 이 PC 안에서만 찾습니다.
// 검색할 때는 서버에 요청하지 않습니다.
(function () {
  "use strict";
  const S = self.KmnSearch;
  const $ = (id) => document.getElementById(id);
  const IS_EXT = !!(self.chrome && chrome.runtime && chrome.runtime.id);
  const PAGE = 40;
  // 확장프로그램에 요청 보내기: 백그라운드가 막 다시 켜지는 중이거나 답이 없어도 오류로 남지 않게
  const send = async (m) => { try { return await chrome.runtime.sendMessage(m); } catch { return null; } };
  // 메일 화면 안 '🔍 빠른 검색' 탭에 들어가 있을 때 (search.html?embed=1): 메일 화면과 같은 모양으로
  const EMBED = /[?&]embed=1/.test(location.search);
  if (EMBED) {
    document.documentElement.classList.add("embed"); document.body.classList.add("embed"); $("openFull").hidden = false;
    // 탭 안에서는 제목 줄을 없애고, 두 버튼(중요 메일 알림·크게 보기)만 필터 줄 오른쪽 끝으로
    const right = document.createElement("span");
    right.className = "hero-right";
    right.append($("openSettings"), $("openFull"));
    document.querySelector(".hero").append(right);
  }

  let recs = [];
  let docs = [];
  let shown = PAGE;
  let lastDoneCount = -1;
  let lastStatus = "";
  const BLANK = { days: 0, folder: "", stype: "", stage: "", topic: "", vendor: "", attach: false, unread: false, quiet: true };
  const filters = Object.assign({}, BLANK);
  let demoSettings = { alertKeywords: ["긴급", "제출"], vipSenders: ["교육지원청"] };

  // ---------- 데이터 ----------
  async function loadData() {
    recs = IS_EXT ? await KmnDB.getAll() : demoData();
    docs = S.prepare(recs);
    render();
  }

  // ---------- 표시 도우미 ----------
  const esc = (s) => String(s).replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));

  function highlight(text, terms, opt) {
    const s = String(text || "");
    const ranges = S.highlightRanges(s, terms, opt);
    if (!ranges.length) return esc(s);
    let out = "", at = 0;
    ranges.forEach(([a, b]) => { out += esc(s.slice(at, a)) + "<mark>" + esc(s.slice(a, b)) + "</mark>"; at = b; });
    return out + esc(s.slice(at));
  }

  function fmtDate(ms) {
    if (!ms) return "";
    const d = new Date(ms), n = new Date();
    const p = (x) => String(x).padStart(2, "0");
    if (d.toDateString() === n.toDateString()) return "오늘 " + p(d.getHours()) + ":" + p(d.getMinutes());
    const y = new Date(n); y.setDate(n.getDate() - 1);
    if (d.toDateString() === y.toDateString()) return "어제 " + p(d.getHours()) + ":" + p(d.getMinutes());
    if (d.getFullYear() === n.getFullYear()) return (d.getMonth() + 1) + "월 " + d.getDate() + "일";
    return d.getFullYear() + ". " + (d.getMonth() + 1) + ". " + d.getDate() + ".";
  }
  const fmtTime = (ms) => new Date(ms).toLocaleTimeString("ko-KR", { hour: "2-digit", minute: "2-digit" });
  const fmtWhen = (ms) => {
    const d = new Date(ms);
    return (d.toDateString() === new Date().toDateString() ? "오늘 " : (d.getMonth() + 1) + "/" + d.getDate() + " ") + fmtTime(ms);
  };

  // 메일함 종류: 받은(in) · 보낸(out) · 내게 쓴(me) · 내가 만든 메일함(my)
  // (예전에 모은 목록에는 종류 번호가 없어 이름으로 짐작)
  function kindOf(r) {
    const at = r.at || 0;
    if (at === 1) return "in";
    if (at === 4) return "out";
    if (at === 8) return "me";
    if (at === 20) return "my";
    const n = r.fn || "";
    if (/내게/.test(n)) return "me";
    if (/보낸/.test(n)) return "out";
    if (/받은/.test(n)) return "in";
    return r.sent ? "out" : "my";
  }

  // ---------- 그리기 ----------
  // 찾을 곳: 전체·메일제목·보낸사람·받는사람은 이 PC 목록에서 바로,
  //          메일본문·첨부이름은 모으지 않으므로 공직자통합메일 화면 검색으로 넘김
  const HANDOFF = { body: "메일본문", attach: "첨부이름" };
  const fieldNow = () => $("field").value;
  const isHandoff = () => !!HANDOFF[fieldNow()];

  function render() {
    const q = $("q").value;
    postQ();
    renderFacets();
    if (isHandoff()) { renderHandoff(q); return; }
    const opt = { field: fieldNow() };
    const res = S.search(docs, q, filters, opt);
    // 알림·광고 메일을 빼서 안 보이는 메일이 몇 통인지 (알려 주고 바로 함께 볼 수 있게)
    res.quietHidden = filters.quiet && !filters.stage && !filters.vendor
      ? S.search(docs, q, Object.assign({}, filters, { quiet: false }), opt).total - res.total : 0;
    renderList(res, q);
  }

  // 메일본문·첨부이름: 결과 자리에 '메일 화면에서 찾기' 안내
  let handoffMsg = "";
  function renderHandoff(q) {
    const name = HANDOFF[fieldNow()];
    const days = { 0: "전체 기간", 7: "1주", 31: "1개월", 92: "3개월", 365: "1년" }[filters.days] || "전체 기간";
    $("list").innerHTML = "";
    $("more").hidden = true;
    $("notice").hidden = true;
    $("summary").innerHTML = esc(name) + " 검색";
    $("empty").hidden = false;
    $("empty").className = "handoff";
    $("empty").innerHTML =
      "<b>" + esc(name) + "은(는) 이 PC에 모아 두지 않습니다.</b><br>" +
      (q.trim()
        ? "공직자통합메일 화면 검색칸에 <b>‘" + esc(q.trim()) + "’</b>을(를) 넣고, 검색 범위 ‘" + esc(name) + "’, 기간 ‘" + esc(days) + "’로 찾아 드립니다."
        : "위 검색칸에 낱말을 쓰고 Enter를 누르면, 공직자통합메일 화면 검색으로 넘겨 찾아 드립니다.") +
      '<br><button type="button" class="primary" id="goServer"' + (q.trim() ? "" : " disabled") + ">메일 화면에서 찾기 ↗</button>" +
      (handoffMsg ? '<div class="res">' + esc(handoffMsg) + "</div>" : "") +
      '<span class="tiny">메일 서버가 찾으므로 시간이 걸릴 수 있습니다. 지금 열려 있는 메일함(보통 받은메일함)에서 찾습니다.</span>';
    $("goServer").onclick = doServerSearch;
  }

  async function doServerSearch() {
    const q = $("q").value.trim();
    if (!q) { $("q").focus(); return; }
    const f = fieldNow();
    if (!IS_EXT) { alert("체험 화면입니다. 확장프로그램에서는 공직자통합메일 화면 검색으로 넘겨 찾습니다."); return; }
    handoffMsg = "메일 화면을 여는 중입니다…";
    if (isHandoff()) render();
    let r = null;
    r = await send({ type: "serverSearch", q, field: f, days: filters.days });
    handoffMsg = {
      ok: EMBED ? "메일 목록 탭에서 찾기 시작했습니다." : "메일 화면에서 찾기 시작했습니다. 메일 화면 탭을 확인하세요.",
      busy: "메일 화면에서 메일을 읽거나 쓰는 중이라 검색칸을 건드리지 않았습니다. 메일 목록으로 돌아간 뒤 다시 눌러 주세요.",
      login: "메일 로그인이 필요합니다. 로그인한 뒤 다시 눌러 주세요."
    }[r && r.result] || "메일 화면을 준비하지 못했습니다. 메일 화면 검색칸에서 직접 찾아 주세요.";
    if (isHandoff()) render(); else toast(handoffMsg);
  }

  function facetButtons(el, entries, current, key, allLabel) {
    el.innerHTML = "";
    const max = Math.max(1, ...entries.map((e) => e.n));
    const total = entries.reduce((a, e) => a + e.n, 0);
    const mk = (label, value, n, isAll, entry) => {
      const b = document.createElement("button");
      b.type = "button";
      if (String(current) === String(value)) b.className = "on";
      if (isAll) b.classList.add("all");
      if (!isAll && !n) b.classList.add("zero");
      if (!isAll && String(current) === String(value)) b.title = "한 번 더 누르면 이 조건을 풉니다";
      const dot = !isAll && entry && entry.kind ? '<i class="dot k-' + entry.kind + '"></i>' : "";
      b.innerHTML = (isAll ? "" : '<i class="fill" style="width:' + Math.round((n / max) * 100) + '%"></i>') +
        "<span>" + dot + esc(label) + '</span><span class="n">' + n.toLocaleString() + "</span>";
      b.onclick = () => { filters[key] = String(current) === String(value) && !isAll ? "" : value; shown = PAGE; render(); };
      el.append(b);
    };
    mk(allLabel, "", total, true);
    entries.forEach((e) => mk(e.label, e.value, e.n, false, e));
    // 이 분류로 걸러 보고 있으면 상자 전체를 눈에 띄게 (제목 옆 '적용 중' 표시)
    const card = el.closest(".card");
    if (card) card.classList.toggle("filtered", !!current);
  }

  function renderFacets() {
    const fc = S.facets(docs, filters, Date.now(), 12);
    facetButtons($("fStage"), S.STAGES.map((x) => ({ label: x, value: x, n: fc.stages[x] || 0 })), filters.stage, "stage", "모든 단계");
    // 거래처: 많이 오간 곳 12곳 (고른 거래처가 그 안에 없어도 맨 위에 보이게)
    const vs = fc.vendors.map((v) => ({ label: v.label, value: v.key, n: v.n }));
    if (filters.vendor && !vs.some((v) => v.value === filters.vendor)) {
      vs.unshift({ label: S.vendorName(docs, filters.vendor) || filters.vendor, value: filters.vendor, n: 0 });
    }
    facetButtons($("fVendor"), vs, filters.vendor, "vendor", "모든 거래처");
    facetButtons($("fTopic"), S.TOPICS.map((x) => ({ label: x, value: x, n: fc.topics[x] || 0 })), filters.topic, "topic", "모든 분야");
    facetButtons($("fStype"), S.SENDER_TYPES.map((x) => ({ label: x, value: x, n: fc.stypes[x] || 0 })), filters.stype, "stype", "모든 곳");

    // 메일함별 개수 (메일함 조건만 빼고 센 값)
    const fNoFolder = Object.assign({}, filters, { folder: "" });
    const byF = new Map();
    const now = Date.now();
    for (const r of recs) {
      if (!byF.has(r.f)) byF.set(r.f, { label: r.fn, value: String(r.f), n: 0, kind: kindOf(r) });
      if (passLocal(r, fNoFolder, now)) byF.get(r.f).n++;
    }
    facetButtons($("fFolder"), [...byF.values()].sort((a, b) => b.n - a.n), filters.folder, "folder", "모든 메일함");

    const any = filters.days || filters.folder || filters.stype || filters.stage || filters.topic || filters.vendor ||
      filters.attach || filters.unread || !filters.quiet || $("q").value.trim();
    $("resetFilters").hidden = !any;
  }

  function passLocal(r, f, now) {
    if (f.days && r.t < now - f.days * 864e5) return false;
    if (f.folder && String(r.f) !== String(f.folder)) return false;
    if (f.stype && r.st !== f.stype) return false;
    if (f.stage && r.sg !== f.stage) return false;
    if (f.topic && r.tp !== f.topic) return false;
    if (f.vendor && r.vk !== f.vendor) return false;
    if (f.attach && !r.x) return false;
    if (f.unread && r.r) return false;
    if (f.quiet && r.qt && !f.stage && !f.vendor) return false;
    return true;
  }

  // 결과의 칩을 눌러 그 분류로 걸러 보기
  function pick(key, value) {
    filters[key] = filters[key] === value ? "" : value;
    shown = PAGE;
    render();
    // 결과 칸만 스크롤되므로 그 칸을 맨 위로 (좁은 화면에서는 창 전체가 스크롤됨)
    const box = document.querySelector(".results");
    if (box) box.scrollTo({ top: 0, behavior: "smooth" });
    window.scrollTo({ top: 0, behavior: "smooth" });
  }

  function renderList(res, q) {
    const ol = $("list");
    ol.innerHTML = "";
    $("empty").hidden = true;
    $("empty").className = "empty";
    const notes = [];
    if (res.partial) notes.push(esc("모든 낱말이 들어간 메일이 없어, 일부 낱말만 맞는 메일을 보여 드립니다."));
    if (res.quietHidden > 0) {
      notes.push("알림·광고 메일 " + res.quietHidden.toLocaleString() + "통(쇼핑몰 주문·배송, 로그인 알림, 광고)은 빼고 보여 드립니다. " +
        '<button type="button" class="linkish" id="showQuiet">함께 보기</button>');
    }
    $("notice").hidden = !notes.length;
    $("notice").innerHTML = notes.join("<br>");
    if ($("showQuiet")) $("showQuiet").onclick = () => { filters.quiet = false; $("fQuiet").checked = false; shown = PAGE; render(); };

    if (!recs.length) {
      $("summary").innerHTML = "";
      $("empty").hidden = false;
      $("more").hidden = true;
      const st = syncNow.status;
      if (st === "running") {
        $("empty").innerHTML = "<b>메일 목록을 모으는 중입니다</b>메일함 하나를 다 모을 때마다 여기서 바로 찾을 수 있습니다. 왼쪽에서 진행 상황을 볼 수 있습니다.";
      } else if (syncNow.loggedOut) {
        $("empty").innerHTML = "<b>먼저 공직자통합메일에 로그인해 주세요</b>로그인한 뒤에 메일 목록을 모을 수 있습니다.";
      } else {
        $("empty").innerHTML = "<b>처음 한 번, 메일 목록을 모아 주세요</b>받은·보낸·내 메일함의 제목과 보낸 사람 목록을 이 PC에 모읍니다. " +
          "본문은 가져오지 않으며, 메일 7천 통이면 2~3분쯤 걸립니다. 한 번 모으면 그다음부터는 새 메일이 저절로 더해집니다." +
          '<br><button type="button" class="primary" id="syncBtn2" style="margin-top:12px">목록 모으기</button>';
        $("syncBtn2").onclick = () => startSync("manual");
      }
      return;
    }

    $("summary").innerHTML = (q.trim() ? "‘" + esc(q.trim()) + "’ " : "") + "검색 결과 <b>" + res.total.toLocaleString() + "</b>통" +
      (res.groups.length !== res.total ? " · 같은 제목끼리 묶어 " + res.groups.length.toLocaleString() + "건" : "");

    if (!res.groups.length) {
      $("empty").hidden = false;
      $("empty").innerHTML = "<b>찾는 메일이 없습니다</b>낱말을 줄이거나, 기간·분류 조건을 풀어 보세요." +
        (q.trim() ? '<br><button type="button" class="tool-btn" id="goServer2" style="margin-top:10px">메일 화면 검색으로 찾기 ↗</button>' : "");
      if ($("goServer2")) $("goServer2").onclick = doServerSearch;
      $("more").hidden = true;
      return;
    }

    const frag = document.createDocumentFragment();
    if (EMBED) {
      // 메일 목록처럼 칸 제목 줄
      const h = document.createElement("li");
      h.className = "ghead";
      h.innerHTML = "<span>" + (fieldNow() === "to" ? "받는사람" : "보낸사람") + "</span><span>제목</span><span>날짜</span>";
      frag.append(h);
    }
    res.groups.slice(0, shown).forEach((g) => frag.append(itemEl(g, res.terms)));
    ol.append(frag);
    $("more").hidden = res.groups.length <= shown;
    $("more").textContent = "더 보기 (" + (res.groups.length - shown).toLocaleString() + "건 남음)";
  }

  function itemEl(g, terms) {
    const r = g.top.d.r;
    const k = kindOf(r);
    const li = document.createElement("li");
    li.className = "item k-" + k + (g.items.some((x) => !x.r) ? " unread" : "");
    // 고른 찾을 곳에서만 노란색 표시 (예: '보낸사람'으로 찾으면 제목은 칠하지 않음)
    const f = fieldNow();
    const toMode = f === "to" && !r.sent;
    const who = toMode ? "받는 사람 " + (r.to || "-")
      : r.sent ? "받는 사람 " + (r.a || r.e || "-") : (r.a || r.e || "보낸 사람 없음");
    const subjTerms = f === "all" || f === "subject" ? terms : [];
    const whoTerms = f === "subject" ? [] : terms;
    const chips = (opt) =>
      (f === "all" ? S.explain(g.top.d, terms) : []).map((x) => '<span class="chip why why-' + x.kind + '" title="이 메일이 찾아진 까닭">' + esc(x.text) + "</span>").join("") +
      (opt.box ? '<span class="chip box k-' + k + '">' + esc(r.fn) + "</span>" : "") +
      (r.sg && r.sg !== "기타" ? '<button type="button" class="chip stage" data-k="stage" data-v="' + esc(r.sg) + '" title="이 단계 메일만 보기">' + esc(r.sg) + "</button>" : "") +
      (r.vk ? '<button type="button" class="chip vendor" data-k="vendor" data-v="' + esc(r.vk) + '" title="이 거래처와 오간 메일 모두 보기">' + esc(r.vd) + "</button>" : "") +
      (r.tp && r.tp !== "기타" ? '<button type="button" class="chip topic" data-k="topic" data-v="' + esc(r.tp) + '" title="이 분야 메일만 보기">' + esc(r.tp) + "</button>" : "") +
      (r.x ? '<span class="chip clip">첨부</span>' : "");
    if (EMBED) {
      // 메일 목록 한 줄 모양: 보낸사람 | 제목 + 분류 | 날짜 (받은메일함이 아니면 메일함 이름도)
      const whoE = toMode ? (r.to || "-") : r.sent ? "→ " + (r.a || r.e || "-") : (r.a || r.e || "보낸 사람 없음");
      li.innerHTML =
        '<div class="main" title="메일보기 탭에서 열기">' +
          '<div class="who" title="' + esc(r.e || r.a || "") + '">' + highlight(whoE.length > 60 ? whoE.slice(0, 60) + "…" : whoE, whoTerms, { cho: f !== "all" }) + "</div>" +
          '<div class="subj"><span class="st">' + highlight(r.s || "(제목 없음)", subjTerms) + "</span>" + chips({ box: k !== "in" }) + "</div>" +
          '<div class="date">' + fmtDate(r.t) + "</div>" +
        "</div>";
    } else li.innerHTML =
      '<div class="main" title="메일 열기">' +
        '<div class="subj">' + highlight(r.s || "(제목 없음)", subjTerms) + "</div>" +
        '<div class="date">' + fmtDate(r.t) + "</div>" +
        '<div class="meta"><span class="who">' + highlight(who.length > 80 ? who.slice(0, 80) + "…" : who, whoTerms, { cho: f !== "all" }) + "</span>" +
          chips({ box: true }) +
        "</div>" +
      "</div>";
    li.querySelector(".main").onclick = (e) => {
      const chip = e.target.closest("button.chip");
      if (chip) { e.stopPropagation(); pick(chip.dataset.k, chip.dataset.v); return; }
      openRec(r);
    };

    if (g.items.length > 1) {
      const det = document.createElement("details");
      det.className = "thread";
      det.innerHTML = "<summary>같은 제목 메일 " + g.items.length + "통 모두 보기 (회신·전달 포함)</summary><ol></ol>";
      const inner = det.querySelector("ol");
      g.items.forEach((x) => {
        const row = document.createElement("li");
        row.innerHTML = '<span><i class="dot k-' + kindOf(x) + '" title="' + esc(x.fn) + '"></i>' + highlight(x.s || "(제목 없음)", subjTerms) +
          ' <span class="d">· ' + esc(x.sent ? "→ " + (x.a || x.e) : (x.a || x.e)) + "</span></span>" +
          '<span class="d">' + fmtDate(x.t) + "</span>";
        row.onclick = () => openRec(x);
        inner.append(row);
      });
      li.append(det);
    }
    return li;
  }

  async function openRec(r) {
    if (IS_EXT) {
      // '빠른 검색' 탭 안이면 메일 화면의 메일보기 탭에서, 따로 연 화면이면 새 창으로
      send({ type: "openMailItem", mailUid: r.u, folderUid: r.f, sent: kindOf(r) === "out", inView: EMBED });
      if (!r.r) {
        r.r = 1; // 이 화면에서만 읽음으로 표시 (메일 서버의 읽음 상태는 메일을 열 때 메일 화면이 바꿈)
        try { await KmnDB.markSeen(r.k); } catch {}
        render();
      }
    } else {
      alert(EMBED ? "체험 화면입니다. 확장프로그램에서는 이 메일이 메일보기 탭에서 열립니다." : "체험 화면입니다. 확장프로그램에서는 이 메일이 새 창으로 열립니다.");
    }
  }

  // ---------- 모으기 상태 ----------
  let syncNow = { status: "", loggedOut: false };
  let syncOpen = false;
  try { syncOpen = localStorage.getItem("kmhSyncOpen") === "1"; } catch {}
  $("syncHead").onclick = () => {
    if (!$("syncCard").classList.contains("can-fold")) return;
    syncOpen = !syncOpen;
    try { localStorage.setItem("kmhSyncOpen", syncOpen ? "1" : "0"); } catch {}
    renderSync();
  };
  async function renderSync() {
    const st = IS_EXT ? await chrome.storage.local.get(["syncState", "loggedOut"]) : { syncState: demoSync() };
    const s = st.syncState || { status: "none" };
    const now = Date.now();
    // 목록이 비었을 때 가운데 안내도 상태에 맞게 바꿈
    const was = syncNow.status + "|" + syncNow.loggedOut;
    syncNow = { status: s.status, loggedOut: !!st.loggedOut };
    if (!recs.length && was !== syncNow.status + "|" + syncNow.loggedOut) render();
    const badge = $("syncBadge"), text = $("syncText"), btn = $("syncBtn");
    const folders = s.folders || [];
    const got = folders.reduce((a, f) => a + Math.min(f.got || 0, f.total || f.got || 0), 0);
    const total = folders.reduce((a, f) => a + (f.total || 0), 0);
    $("syncBarWrap").hidden = s.status !== "running";
    $("syncFolders").textContent = "";
    btn.disabled = false;

    if (s.status === "running") {
      badge.className = "badge run"; badge.textContent = "모으는 중";
      text.textContent = (s.current ? "‘" + s.current + "’ " : "") + "목록을 천천히 모으고 있습니다. 이 화면을 닫아도 계속됩니다.";
      $("syncBar").style.width = (total ? Math.round((got / total) * 100) : 3) + "%";
      $("syncFolders").textContent = folders.map((f) => f.text + " " + (f.got || 0).toLocaleString() + "/" + (f.total || 0).toLocaleString()).join(" · ");
      btn.disabled = true; btn.textContent = "모으는 중…";
    } else if (s.status === "done") {
      badge.className = "badge ok"; badge.textContent = (s.count || recs.length).toLocaleString() + "통";
      text.textContent = "마지막 전체 맞춤 " + fmtWhen(s.lastFullSync) + ". 새 메일은 알림 확인 때 저절로 더해지고, 하루 한 번 전체를 다시 맞춥니다.";
      $("syncShort").textContent = "마지막 맞춤 " + fmtWhen(s.lastFullSync) + " · 새 메일은 저절로 더함";
      const next = s.lastFullSync + 30 * 60e3;
      btn.textContent = now < next ? fmtTime(next) + " 이후 다시 모을 수 있음" : "지금 다시 모으기";
      btn.disabled = now < next;
    } else if (s.status === "paused") {
      badge.className = "badge bad"; badge.textContent = "멈춤";
      text.textContent = (/연결/.test(s.error || "") ? "메일 서버에 연결하지 못해 멈췄습니다. 인터넷이 다시 연결되면" : "로그인이 풀려 멈췄습니다. 메일에 다시 로그인하면") +
        " 몇 분 안에 저절로 이어서 모읍니다. 바로 이어 가려면 아래 버튼을 누르세요.";
      btn.textContent = "이어서 모으기";
    } else if (s.status === "error") {
      badge.className = "badge bad"; badge.textContent = "쉬는 중";
      const until = s.pausedUntil || 0;
      text.textContent = "오류가 나서 잠시 멈췄습니다" + (s.error ? " (" + s.error + ")" : "") + ". 서버 부담을 줄이려고 " +
        (now < until ? fmtTime(until) + "까지 기다린 뒤 저절로 한 번 더 해 봅니다." : "기다렸습니다. 다시 해 볼 수 있습니다.");
      btn.textContent = now < until ? fmtTime(until) + " 이후 가능" : "다시 해 보기";
      btn.disabled = now < until;
    } else {
      badge.className = "badge"; badge.textContent = "아직 없음";
      text.textContent = "받은·보낸·내 메일함의 제목과 보낸 사람 목록을 한 번 모읍니다. 메일 7천 통이면 2~3분쯤 걸리며, 그동안 다른 일을 하셔도 됩니다.";
      btn.textContent = "목록 모으기";
    }
    if (st.loggedOut && s.status !== "running") {
      text.textContent = "지금은 메일 로그인이 풀려 있습니다. 메일에 로그인해야 목록을 모을 수 있습니다. 이미 모아 둔 목록은 검색할 수 있습니다.";
      btn.disabled = true;
    }
    // 다 모았고 별일 없으면 두 줄로 작게 접어 둠 (제목을 누르면 펼침). 모으는 중·멈춤·오류·로그인 풀림은 늘 펼쳐 보여 줌
    const calm = s.status === "done" && !st.loggedOut;
    $("syncCard").classList.toggle("can-fold", calm);
    $("syncCard").classList.toggle("folded", calm && !syncOpen);
    $("syncHead").title = calm ? (syncOpen ? "눌러서 접기" : "눌러서 펼치기 (다시 모으기·서버 부담 안내)") : "";

    // 메일함 하나를 다 모을 때마다, 그리고 끝났을 때 목록을 다시 읽음
    const doneCount = (s.doneIds || []).length;
    if ((s.status !== lastStatus && s.status === "done") || (s.status === "running" && doneCount !== lastDoneCount && lastDoneCount !== -1)) {
      if (IS_EXT) loadData();
    }
    lastDoneCount = doneCount;
    lastStatus = s.status;
  }

  async function startSync(kind) {
    if (!IS_EXT) return;
    const r = await send({ type: "syncRequest", kind });
    if (r && !r.ok && kind === "manual") {
      const msg = { tooSoon: "조금 전에 모았습니다. " + (r.until ? fmtTime(r.until) + " 이후" : "잠시 뒤") + "에 다시 해 주세요.",
        backoff: "오류 뒤 쉬는 중입니다. " + (r.until ? fmtTime(r.until) + " 이후" : "잠시 뒤") + "에 다시 해 주세요.",
        login: "메일 로그인이 풀려 있습니다. 먼저 로그인해 주세요." }[r.why];
      if (msg) alert(msg);
    }
    renderSync();
  }

  // ---------- 설정 (⭐ 알림) ----------
  const toList = (t) => t.split(/[\n,]/).map((x) => x.trim()).filter(Boolean).slice(0, 50);
  async function getSettings() {
    if (!IS_EXT) return demoSettings;
    const { settings } = await chrome.storage.local.get("settings");
    return settings || {};
  }
  async function openSettings() {
    if ($("settings").open) return;
    const s = await getSettings();
    $("kw").value = (s.alertKeywords || []).join("\n");
    $("vip").value = (s.vipSenders || []).join("\n");
    $("settings").showModal();
  }
  $("openSettings").onclick = openSettings;
  $("openFull").onclick = () => {
    if (!IS_EXT) { alert("체험 화면입니다. 확장프로그램에서는 새 탭에 넓은 검색 화면이 열립니다."); return; }
    send({ type: "openSearch", q: $("q").value.trim() });
  };
  $("saveSettings").onclick = async () => {
    // 같은 낱말을 두 번 적었으면 하나만
    const uniq = (a) => [...new Set(a)];
    const patch = { alertKeywords: uniq(toList($("kw").value)), vipSenders: uniq(toList($("vip").value)) };
    if (IS_EXT) {
      const { settings } = await chrome.storage.local.get("settings");
      await chrome.storage.local.set({ settings: { ...(settings || {}), ...patch } });
    } else {
      demoSettings = patch;
    }
    toast("저장했습니다. 다음 새 메일 알림부터 ⭐로 표시합니다.");
  };

  let toastT = 0;
  function toast(msg) {
    const el = $("toast");
    el.textContent = msg;
    el.hidden = false;
    clearTimeout(toastT);
    toastT = setTimeout(() => { el.hidden = true; }, 3000);
  }

  // ---------- 조작 ----------
  let timer = 0;
  $("q").addEventListener("input", () => { clearTimeout(timer); timer = setTimeout(() => { shown = PAGE; handoffMsg = ""; render(); }, 140); });
  // 메일본문·첨부이름일 때 Enter = 메일 화면에서 찾기
  $("q").addEventListener("keydown", (e) => {
    if (e.key === "Enter" && !e.isComposing && isHandoff()) { e.preventDefault(); doServerSearch(); }
  });
  $("field").onchange = () => {
    handoffMsg = ""; shown = PAGE;
    $("q").placeholder = isHandoff()
      ? HANDOFF[fieldNow()] + "에서 찾을 낱말을 쓰고 Enter (메일 화면 검색으로 넘김)"
      : { all: "제목·보낸 사람·거래처로 찾기 (예: 계산서, ㄱㅅㅅ·ㄳㅅ, 견적서, 소독)", subject: "메일 제목에서 찾기 (예: 견적서, ㄱㅈㅅ)",
          from: "보낸 사람 이름·주소에서 찾기 (예: 관광, naver)", to: "받는 사람 이름·주소에서 찾기" }[fieldNow()];
    render(); $("q").focus();
  };
  // 한글 자판이 ㄱ+ㅅ을 ㄳ로 합친 경우, 글자 입력이 끝나면 칸에도 ㄱㅅ으로 나눠 보여 줌
  // (검색은 입력 중에도 나눠서 찾음)
  const splitBox = () => {
    const el = $("q"), v = el.value, n = S.splitJamo(v);
    if (n === v) return;
    const pos = el.selectionStart == null ? v.length : el.selectionStart;
    const p = S.splitJamo(v.slice(0, pos)).length; // 나눈 뒤에도 커서를 같은 글자 뒤에
    el.value = n;
    try { el.setSelectionRange(p, p); } catch {}
  };
  $("q").addEventListener("compositionend", () => setTimeout(splitBox, 0));
  $("q").addEventListener("blur", splitBox);
  document.addEventListener("keydown", (e) => {
    if (e.key === "/" && document.activeElement !== $("q") && !$("settings").open && !/TEXTAREA|INPUT/.test(document.activeElement.tagName)) { e.preventDefault(); $("q").focus(); }
    if (e.key === "Escape" && document.activeElement === $("q") && $("q").value) { $("q").value = ""; render(); }
  });
  $("periods").querySelectorAll("button").forEach((b) => {
    b.onclick = () => {
      $("periods").querySelectorAll("button").forEach((x) => x.classList.toggle("on", x === b));
      filters.days = Number(b.dataset.days) || 0; shown = PAGE; render();
    };
  });
  $("fUnread").onchange = (e) => { filters.unread = e.target.checked; shown = PAGE; render(); };
  $("fAttach").onchange = (e) => { filters.attach = e.target.checked; shown = PAGE; render(); };
  $("fQuiet").onchange = (e) => { filters.quiet = e.target.checked; shown = PAGE; render(); };
  $("more").onclick = () => { shown += PAGE; render(); };
  $("resetFilters").onclick = () => {
    Object.assign(filters, BLANK);
    $("q").value = ""; $("fUnread").checked = false; $("fAttach").checked = false; $("fQuiet").checked = true;
    $("periods").querySelectorAll("button").forEach((x, i) => x.classList.toggle("on", i === 0));
    shown = PAGE; render();
  };
  $("syncBtn").onclick = () => startSync("manual");
  $("clearData").onclick = async () => {
    if (!confirm("이 PC에 모아 둔 메일 목록을 지울까요?\n메일 서버의 메일은 지워지지 않습니다. 다시 쓰려면 목록을 새로 모아야 합니다.")) return;
    if (!IS_EXT) { recs = []; docs = []; render(); return; }
    const r = await send({ type: "syncClear" });
    if (r && !r.ok) { alert("목록을 모으는 중에는 지울 수 없습니다. 끝난 뒤 다시 해 주세요."); return; }
    await loadData(); renderSync();
  };

  if (IS_EXT) {
    let reloadT = 0;
    chrome.storage.onChanged.addListener((ch) => {
      if (ch.syncState || ch.loggedOut) renderSync();
      // 새 메일 확인 때 목록에 새 메일이 더해지면, 열어 둔 검색 화면에도 보이게 다시 읽음
      if (ch.dbTouched) { clearTimeout(reloadT); reloadT = setTimeout(loadData, 500); }
    });
    setInterval(renderSync, 30000); // '…이후 가능' 시각이 지나면 버튼을 다시 켬
  }

  // ---------- 체험용 예시 (확장프로그램 밖에서 열었을 때만) ----------
  function demoSync() {
    return { status: "done", lastFullSync: Date.now() - 2 * 3600e3, count: recs.length };
  }
  function demoData() {
    const now = Date.now(), day = 864e5;
    const IN = { id: 1, text: "받은메일함", actionType: 1 }, OUT = { id: 2, text: "보낸메일함", actionType: 4 }, MY = { id: 3, text: "2026 방과후", actionType: 20 };
    // 학교 행정실 메일함처럼: 대부분 업체와 주고받는 메일 (이름·주소는 지어낸 것)
    const rows = [
      ["[긴급] 냉난방기 실외기 고장 수리 견적서 송부", "(주)한빛공조", "hanbit.air@naver.com", 0.2, 0, 1, IN],
      ["한빛초등학교 (주식회사 한빛공조->한빛초등학교)", "TaxBill365", "noreply@taxbill365.com", 0.5, 0, 0, IN],
      ["냉난방기 수리 완료 사진대지 및 작업확인서", "(주)한빛공조", "hanbit.air@naver.com", 1.1, 1, 1, IN],
      ["RE: 냉난방기 실외기 수리 견적 요청드립니다", "행정실", "office@korea.kr", 3, 1, 0, OUT, "(주)한빛공조"],
      ["한빛초등학교 고유번호증 보내드립니다", "행정실", "office@korea.kr", 2.8, 1, 1, OUT, "(주)한빛공조"],
      ["전자세금계산서 보내드립니다 (11월분 복합기 임차료)", "(주)바른오에이", "barun.oa@hanmail.net", 0.6, 0, 1, IN],
      ["(주)바른오에이 11월 복합기 사용량 청구서입니다", "(주)바른오에이", "barun.oa@hanmail.net", 0.7, 1, 1, IN],
      ["12월 친환경농산물 납품 거래명세서", "○○농원", "farm.okay@naver.com", 0.9, 1, 1, IN],
      ["급식실 소독증명서(한빛초등학교 12월)", "맑은방역", "clean.bang@nate.com", 1.4, 1, 1, IN],
      ["어린이놀이시설 기생충란검사 성적서 송부드립니다", "안전놀이협동조합", "safeplay@safeplay.or.kr", 4, 1, 1, IN],
      ["[G마켓] 주문하신 상품이 발송되었습니다", "G마켓", "mailmaster@corp.gmarket.co.kr", 1.3, 1, 0, IN],
      ["한빛초등학교님, 결제가 완료되었습니다.", "G마켓", "mailmaster@corp.gmarket.co.kr", 1.5, 1, 0, IN],
      ["[11번가] 간편 로그인 등록 안내 입니다.", "11번가", "help@11st.co.kr", 6, 1, 0, IN],
      ["[광고] 겨울방학 교구 모음전 최대 40% 할인", "교구나라", "ad@gyogu.co.kr", 2, 1, 0, IN],
      ["S2B에서 계약이 체결되었습니다 (교실 책상·의자)", "S2B(학교장터)", "noreply@s2b.kr", 8, 1, 0, IN],
      ["[국세청] 전자세금계산서가 발급되었습니다", "국세청", "noreply@hometax.go.kr", 8.5, 1, 0, IN],
      ["12월 5일 현장체험학습 전세버스 견적 요청", "행정실", "office@korea.kr", 12, 1, 0, OUT, "푸른관광"],
      ["[푸른관광] 12/5 차량운행 배차서류 입니다", "푸른관광", "blue.tour@naver.com", 10, 1, 1, IN],
      ["RE: 영어 기간제교원 지원서입니다", "지원자", "apply.eng@gmail.com", 15, 1, 1, IN],
      ["보건실 약품구입 서류입니다", "바른약품", "medi@barunmedi.co.kr", 20, 1, 1, IN],
      ["학교 급수관 배관세척 용역 업체 안내", "맑은물환경", "water.c@hanmail.net", 26, 1, 0, IN],
      ["11월 전기요금 청구서입니다", "한국전력공사", "bill@kepco.co.kr", 31, 1, 0, IN],
      ["온비드 사용방법 설명회(동산편) 참석 안내", "한국자산관리공사", "onbid@onbid.co.kr", 40, 1, 0, IN],
      ["한빛초등학교 시설 일시 사용 허가서 보내드립니다", "행정실", "office@korea.kr", 47, 1, 1, OUT, "○○동 주민자치회"],
      ["2027 본예산 편성 기본 계획 알림", "○○교육지원청 행정지원과", "budget@goe.go.kr", 60, 1, 1, IN],
      ["안전보건 협의체 방문 일정 확정 안내", "학교안전사회적협동조합", "safe@safeschool.co.kr", 80, 1, 0, IN],
      ["CCTV 유지보수 용역 계약 만료 안내", "(주)세이프넷", "care@safenet.co.kr", 110, 1, 0, IN],
      ["내 PC 백업 파일", "나", "", 200, 1, 1, { id: 4, text: "내게쓴메일함", actionType: 8 }, "나"]
    ];
    let uid = 9000;
    return rows.map(([s, from, mail, ago, seen, att, folder, to]) => S.toRecord({
      mailUid: uid++, subject: s, adrFrom: from, adrFromTooltip: mail, adrTo: to || "", adrToTooltip: "",
      timeMillis: now - ago * day, isSeen: seen, flagAttach: att
    }, folder));
  }

  // ---------- 왼쪽 분류 상자 펼치기·접기 ----------
  // 제목을 누르면 펼치고 접음. 접어 두어도 고른 조건은 그 한 줄만 보여 줘서 무엇으로 걸렀는지 알 수 있게.
  // 펼침 상태는 이 PC에 기억 (처음엔 '거래처'만 펼침)
  const OPEN_KEY = "kmhFacetOpen";
  function loadOpen() {
    try { const v = JSON.parse(localStorage.getItem(OPEN_KEY)); if (v && typeof v === "object") return v; } catch {}
    return { fVendor: true };
  }
  function setupCollapse() {
    const open = loadOpen();
    document.querySelectorAll(".card .facet").forEach((fc) => {
      const card = fc.closest(".card"), title = card.querySelector(".facet-title");
      if (!title) return;
      const chev = document.createElement("span");
      chev.className = "chev";
      chev.setAttribute("aria-hidden", "true");
      title.append(chev);
      title.setAttribute("role", "button");
      title.tabIndex = 0;
      const apply = (isOpen) => {
        card.classList.toggle("collapsed", !isOpen);
        title.setAttribute("aria-expanded", String(isOpen));
        title.title = isOpen ? "눌러서 접기" : "눌러서 펼치기";
      };
      apply(!!open[fc.id]);
      const toggle = () => {
        const isOpen = card.classList.contains("collapsed");
        apply(isOpen);
        open[fc.id] = isOpen;
        try { localStorage.setItem(OPEN_KEY, JSON.stringify(open)); } catch {}
      };
      title.onclick = toggle;
      title.onkeydown = (e) => { if (e.key === "Enter" || e.key === " ") { e.preventDefault(); toggle(); } };
    });
  }
  setupCollapse();

  // ---------- 시작 ----------
  // 메일 화면의 '빠른 검색'으로 낱말이 넘어오면 검색창에 넣고 찾기
  function applyHash() {
    if (/^#settings/.test(location.hash)) { openSettings(); return false; } // 팝업의 '⭐ 중요 메일 알림 설정'
    const m = location.hash.match(/^#q=([^&]*)/); // 뒤의 &t=… 는 같은 낱말을 다시 넘겨도 바뀐 것으로 알게 하는 표시
    if (!m) return false;
    let v = "";
    try { v = decodeURIComponent(m[1]); } catch { v = m[1]; }
    $("q").value = S.splitJamo(v);
    return true;
  }
  // &nf=1: 메일 화면 위쪽 검색칸에서 치는 중 → 이 화면이 글자 입력 자리를 빼앗지 않음
  const noFocusHash = () => /[#&]nf=1/.test(location.hash);
  window.addEventListener("hashchange", () => { if (applyHash()) { shown = PAGE; render(); if (!noFocusHash()) $("q").focus(); } });

  // 메일 화면 위쪽 '빠른 검색' 칸과 주고받기 (탭 안에 있을 때만, 메일 화면에서 온 것만)
  // 받는 것: 찾을 낱말 / 보내는 것: 지금 낱말 (탭 안에서 '조건 모두 풀기' 등으로 바뀌면 위쪽 칸도 맞춤)
  const PARENT = "https://kmmbox.korea.kr";
  let lastPosted = null;
  function postQ() {
    if (!EMBED || window.parent === window) return;
    const v = $("q").value;
    if (v === lastPosted) return;
    lastPosted = v;
    try { window.parent.postMessage({ kmhQuick: "q", q: v }, PARENT); } catch {}
  }
  if (EMBED) {
    window.addEventListener("message", (e) => {
      if (e.origin !== PARENT || e.source !== window.parent) return;
      const d = e.data;
      // 메일 화면 위쪽에 검색칸이 붙어 있다는 인사 → 이 안의 검색칸은 숨겨 자리를 아낌 (찾을 곳 고르기만 남김)
      if (d && d.kmhQuick === "hello") { document.documentElement.classList.add("has-topbox"); lastPosted = null; postQ(); return; }
      // 위쪽 칸에서 Enter: 메일본문·첨부이름이면 메일 화면 검색으로 넘김
      if (d && d.kmhQuick === "enter") { if (isHandoff()) doServerSearch(); return; }
      if (!d || d.kmhQuick !== "setQ" || typeof d.q !== "string") return;
      const v = S.splitJamo(d.q.slice(0, 100));
      lastPosted = v; // 보낸 쪽에 되돌려 보내지 않음
      if ($("q").value === v) return;
      $("q").value = v; shown = PAGE; handoffMsg = ""; render();
    });
    // 위쪽 검색칸이 있는지 물어봄 (없으면 이 안의 검색칸을 그대로 씀)
    try { window.parent.postMessage({ kmhQuick: "ready" }, PARENT); } catch {}
  }

  (async () => {
    applyHash();
    await loadData();
    await renderSync();
    if (IS_EXT) startSync("auto"); // 하루가 지났으면 조용히 전체 맞춤 (첫 모으기는 버튼으로)
    if (!EMBED) $("q").focus(); // 탭 안에서는 메일 화면 위쪽 검색칸을 씀
  })();
})();
