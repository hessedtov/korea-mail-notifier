const DEFAULTS = { intervalMin: 3, keepAlive: true, nativeNotice: true };
const $ = (id) => document.getElementById(id);

function fmt(ms) {
  if (!ms) return "-";
  const d = new Date(ms);
  return d.toLocaleTimeString("ko-KR", { hour: "2-digit", minute: "2-digit" });
}

function render(st) {
  const box = $("status");
  if (st.loggedOut) {
    box.className = "status bad";
    box.innerHTML = "<b>로그인이 풀렸습니다.</b><br><span class='muted'>‘메일 열기’로 다시 로그인해 주세요.</span>";
  } else if (st.lastCheck) {
    box.className = "status";
    box.innerHTML =
      "<div class='big'>" + (st.unread ?? 0) + "통</div>안 읽은 메일" +
      "<div class='muted'>마지막 확인 " + fmt(st.lastCheck) +
      (st.settings && st.settings.keepAlive && st.lastExtend
        ? " · 자동 연장 " + fmt(st.lastExtend) + (st.lastExtendOk ? "" : " (실패)") : "") + "</div>";
  } else {
    box.className = "status";
    box.textContent = "아직 확인 전입니다. 메일에 로그인하면 몇 분 안에 저절로 확인합니다. 바로 보려면 ‘지금 확인’을 누르세요.";
  }
  // 진단 정보 (문제가 있을 때 화면 캡처로 보내 주면 원인 파악에 씀)
  const diag = [];
  if (st.lastError) diag.push("오류: " + st.lastError);
  if (st.checkDiag) diag.push("메일 확인 " + st.checkDiag);
  if (st.settings && st.settings.keepAlive && st.extendDiag) diag.push("자동 연장 " + (st.lastExtendOk ? "성공" : "실패") + ": " + st.extendDiag);
  $("diag").textContent = diag.join("\n");
  $("diag").hidden = diag.length === 0;

  const ul = $("recent");
  ul.innerHTML = "";
  (st.recent || []).forEach((m) => {
    const li = document.createElement("li");
    if (!m.seen) li.className = "unseen";
    const b = document.createElement("b");
    b.textContent = m.subject || "(제목 없음)";
    const s = document.createElement("div");
    s.className = "muted";
    s.textContent = (m.from || "") + " · " + fmt(m.time);
    li.append(b, s);
    ul.append(li);
  });
}

async function load() {
  const st = await chrome.storage.local.get(null);
  const s = { ...DEFAULTS, ...(st.settings || {}) };
  $("intervalMin").value = String(s.intervalMin);
  $("keepAlive").checked = s.keepAlive;
  $("nativeNotice").checked = s.nativeNotice;
  render(st);
}

async function save() {
  const st = await chrome.storage.local.get("settings");
  const s = {
    ...DEFAULTS, ...(st.settings || {}),
    intervalMin: Number($("intervalMin").value),
    keepAlive: $("keepAlive").checked,
    nativeNotice: $("nativeNotice").checked
  };
  await chrome.storage.local.set({ settings: s });
  send({ type: "settingsChanged" });
}

["intervalMin", "keepAlive", "nativeNotice"].forEach((id) => $(id).addEventListener("change", save));
// 요청이 실패하거나 답이 없어도 오류로 남지 않게
async function send(m) { try { return await chrome.runtime.sendMessage(m); } catch { return null; } }
$("open").onclick = async () => { await send({ type: "openMail" }); window.close(); };
$("check").onclick = async () => {
  $("status").textContent = "확인 중…";
  const st = await send({ type: "checkNow" });
  if (st) render(st); else load();
};
$("test").onclick = async () => {
  const r = await send({ type: "testNotice" });
  if (r && r.ok === false) load(); // 실패 이유를 진단 칸에 보여 줌
};
$("search").onclick = async () => { await send({ type: "openSearch" }); window.close(); };
$("star").onclick = async () => { await send({ type: "openSearch", settings: true }); window.close(); };
$("guide").onclick = async () => { try { await chrome.tabs.create({ url: "welcome.html" }); } catch {} window.close(); };
$("ver").textContent = "버전 " + chrome.runtime.getManifest().version;

load();
