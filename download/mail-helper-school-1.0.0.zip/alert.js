// 오른쪽 아래 알림 창. 사용자가 '메일 열기'나 '닫기'를 눌러야 닫힙니다.
const $ = (id) => document.getElementById(id);

function hhmm(ms) {
  return ms ? new Date(ms).toLocaleTimeString("ko-KR", { hour: "2-digit", minute: "2-digit" }) : "";
}

async function render() {
  const { popupMails = [], popupUnread = 0, popupLogout = false } =
    await chrome.storage.local.get(["popupMails", "popupUnread", "popupLogout"]);

  const hasMail = popupMails.length > 0;
  const onlyLogout = popupLogout && !hasMail;

  $("title").textContent = onlyLogout ? "⚠️ 메일 로그인이 풀렸습니다" : "📬 새 메일 " + popupMails.length + "통이 도착했습니다";
  $("title").className = onlyLogout ? "warn" : "";
  $("sub").textContent = onlyLogout ? "" : "안 읽은 메일 " + popupUnread + "통" + (popupLogout ? " · 지금은 로그인이 풀린 상태입니다" : "");
  $("logoutMsg").hidden = !onlyLogout;
  $("list").hidden = onlyLogout;
  $("open").textContent = onlyLogout ? "다시 로그인" : "메일 열기";
  document.title = onlyLogout ? "메일 로그인 해제" : "새 메일 " + popupMails.length + "통";

  const ul = $("list");
  ul.innerHTML = "";
  popupMails.forEach((m) => {
    const li = document.createElement("li");
    const b = document.createElement("b");
    b.textContent = m.subject || "(제목 없음)";
    b.title = m.subject || "";
    const s = document.createElement("span");
    s.className = "muted";
    s.textContent = (m.from || "") + " · " + hhmm(m.time);
    if (m.star) {
      li.className = "star";
      const t = document.createElement("span");
      t.className = "tag";
      t.textContent = "⭐ " + m.star;
      li.append(t);
    }
    li.append(b, s);
    ul.append(li);
  });
}

// 다른 일을 하다 Enter를 눌러도 버튼이 눌리지 않도록 처음엔 어떤 버튼에도 포커스를 두지 않음
window.addEventListener("load", () => document.activeElement && document.activeElement.blur());

$("open").onclick = async () => {
  try { await chrome.runtime.sendMessage({ type: "openMail" }); } catch {}
  window.close();
};
$("ok").onclick = () => window.close();

chrome.storage.onChanged.addListener((changes) => {
  if (changes.popupMails || changes.popupUnread || changes.popupLogout) render();
});

render();
